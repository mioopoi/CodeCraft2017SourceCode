#ifndef __ROUTE_H__
#define __ROUTE_H__

#include "lib_io.h"

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wwrite-strings"
#pragma GCC diagnostic ignored "-Wsign-compare"
void deploy_server(char * graph[MAX_EDGE_NUM], int edge_num, char * filename);



#endif
