#ifndef __GLOBALS_H__
#define __GLOBALS_H__

const int MAX_OUT_EDGE = 20;

#endif