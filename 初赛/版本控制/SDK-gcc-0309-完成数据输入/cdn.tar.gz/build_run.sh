#!/bin/bash

./build.sh

cd ./bin

./cdn ../case_example/case0.txt ./result.txt