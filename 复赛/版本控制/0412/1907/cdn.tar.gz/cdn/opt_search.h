#ifndef __OPT_SEARCH_H__
#define __OPT_SEARCH_H__

#include <iostream>
#include <vector>
#include <algorithm>

#include "opt_search_helper.h"
#include "graph.h"
#include "zkw_mcf.h"

using namespace std;

class OptSearch
{
public:
    Graph* graph;
    ZkwMcf* zkw_mcf;
    int node_num;
    int customer_num;
    int level_num;

    vector<Candidate*> candidates;
    vector<Candidate*> candidates_cp;
    vector<Candidate*> increase_candidates;
    vector<Candidate*> increase_candidates_cp;

    Candidate* candidate_start_ptr;

    OptSearch(Graph* graph);
    void init_candidates();
    void calculate_candidates_neighbor();

    bool run_server_level_mcf();
    bool run_max_level_mcf();
    void construct_candidates_by_demand();
    void construct_first_solution_by_node_demand();
    void construct_first_solution_by_node_demand_with_max_level();
    void construct_first_solution_by_node_max_flow();
    void construct_first_solution_combine_demand_and_flow();

    void deal_with_topo_lv0_zero();
    void deal_with_topo_lv0_one();
    void deal_with_topo_lv0_two();
    void deal_with_topo_lv0_three();
    bool decrease_server_with_max_level();
    bool increase_server_with_max_level();
    void update_global_min_cost();
    void set_mcf_state(int which = 0);
    bool remove_a_server(int server_id);
    bool add_a_server(int server_id);


    int choose_server_by_node_demand(double percent);
    int choose_server_by_node_max_flow(bool re_cal, double percent);

    bool down_server_level();
    void calculate_candidates_overflow_cost();
    bool calculate_candidates_pass_cost();

    bool exchange_server_by_node_pass_cost();
    bool exchange_one_node_with_all_server(int in_id);
    int exchange_node(int in_id, int in_lv, int out_id, int& real_lv);
    void topo_strategy();
    void deal_with_topo_lv2_zero();
    bool exchange_one_server_with_other_candidates(int out_id);
    bool exchange_server_by_node_pass_cost_lv2();

    int global_min_cost;
    int global_flow_cost;
    int* servers;
    int* pre_servers;
    Candidate* empty_candidate;

    int topo_lv;

};

OptSearch::OptSearch(Graph* graph)
{
    this->graph = graph;
    zkw_mcf = new ZkwMcf(graph);
    node_num = graph->node_num;
    customer_num =graph->customer_num;
    level_num = graph->level_num;

    servers = new int[node_num];
    pre_servers = new int[node_num];

    memset(servers, -1, sizeof(int) * node_num);

    global_min_cost = 0;
    init_candidates();

    if(node_num < 200) topo_lv = 0;
    else if(node_num < 500) topo_lv = 1;
    else topo_lv = 2;

}

void OptSearch::init_candidates()
{
    int candidate_ptr_cnt = 0;
    candidate_start_ptr = new Candidate[node_num + 2];

    empty_candidate = new (candidate_start_ptr + candidate_ptr_cnt) Candidate();
    candidate_ptr_cnt++;
    increase_candidates = vector<Candidate*>(node_num, empty_candidate);

    candidates = vector<Candidate*>(node_num, NULL);
    candidates_cp = vector<Candidate*>(node_num, NULL);

    bool is_customer;
    int demand;
    for(int i = 0; i < node_num; i++)
    {
        //cout<<g_node_customer[i]<<endl;
        //int node_id = -1, bool is_customer = 0, int demand = -1, int node_cost = 100000, bool is_server = false, int  server_level = -
        if(g_node_customer[i] != -1)
        {
            is_customer = true;
            demand = g_customer_need[g_node_customer[i]];
        }
        else
        {
            is_customer = false;
            demand = 0;
        }
        candidates[i] = new (candidate_start_ptr + candidate_ptr_cnt) Candidate(i, is_customer, demand, g_node_cost[i], false, -1);
        candidates_cp[i] = candidates[i];
        candidate_ptr_cnt++;
    }
}

void OptSearch::construct_candidates_by_demand()
{
    sort(candidates.begin(), candidates.end(), candidate_demand_cmp_greater());
    /*for(int i = 0; i < node_num; i++)
    {
        cout<<candidates[i]->node_id<<" "<<candidates[i]->demand<<endl;
    }*/
}

void OptSearch::construct_first_solution_by_node_demand()
{
    construct_candidates_by_demand();
    bool is_satisfied, is_all_satisfied = true;
    int j, demand, node_id;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        demand = candidates[i]->demand;
        if(demand == 0) break;
        is_satisfied = false;
        for(j = 0; j < graph->level_num; j++)
        {
            if(g_server_level[j].power >= demand)
            {
                is_satisfied = true;
                break;
            }
        }

        if(is_satisfied)
        {
            servers[node_id] = j;
            global_min_cost += (g_server_level[j].cost + g_node_cost[node_id]);
        }
        else
        {
            is_all_satisfied = false;
            cout<<"node: "<<node_id<<"is not satisfied"<<endl;
            servers[node_id] = j - 1;
        }
    }

    if(is_all_satisfied)
    {
        cout<<"global_min_cost after construct first demand: "<<global_min_cost<<endl;
        return;
    }
}

void OptSearch::construct_first_solution_by_node_demand_with_max_level()
{
    construct_candidates_by_demand();
    bool is_satisfied, is_all_satisfied = true;
    int j, demand, node_id;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        demand = candidates[i]->demand;
        if(demand == 0) break;
        is_satisfied = false;
        if(g_server_level[level_num - 1].power >= demand)
            is_satisfied = true;
        if(is_satisfied)
        {
            servers[node_id] = level_num - 1;
            global_min_cost += (g_server_level[level_num - 1].cost + g_node_cost[node_id]);
        }
        else
        {
            is_all_satisfied = false;
            cout<<"node: "<<node_id<<"is not satisfied"<<endl;
            servers[node_id] = level_num - 1;
        }
    }

    if(is_all_satisfied)
    {
        cout<<"global_min_cost after construct first demand: "<<global_min_cost<<endl;
        return;
    }
}

int OptSearch::choose_server_by_node_demand(double percent)
{
    sort(candidates.begin(), candidates.end(), candidate_demand_cmp_greater());

    int cus_num = int(customer_num * percent);
    int cus_cnt = 0, node_id;
    for(int i = 0; i < cus_num; i++)
    {
        node_id = candidates[i]->node_id;
        increase_candidates[node_id] = candidates[i];
        servers[node_id] = level_num - 1;
    }

    //sort(increase_candidates.begin(), increase_candidates.end(), candidate_demand_cmp_greater());
    //for(int i = 0; i < node_num; i++)
    //cout<<increase_candidates[i]->node_id<<endl;
    return cus_num;
}

int OptSearch::choose_server_by_node_max_flow(bool re_cal, double percent)
{
    if(re_cal)  calculate_candidates_neighbor();
    sort(candidates.begin(), candidates.end(), candidate_flow_cmp_greater());

    int middle_num = int(node_num * percent);
    int node_id;
    for(int i = 0; i < middle_num; i++)
    {
        node_id = candidates[i]->node_id;
        increase_candidates[node_id] = candidates[i];
        servers[node_id] = level_num - 1;
    }
    return middle_num;
}

void OptSearch::construct_first_solution_combine_demand_and_flow()
{
    double p0 = 0.1, p1 = 0.1;
    choose_server_by_node_demand(p0);
    choose_server_by_node_max_flow(true, p1);
    bool is_feasible = run_max_level_mcf();
    while(!is_feasible)
    {
        p0 += 0.02;
        p1 += 0.1;
        cout<<p0<<" "<<p1<<endl;
        choose_server_by_node_demand(p0);
        choose_server_by_node_max_flow(false, p1);
        is_feasible = run_max_level_mcf();
    }
    increase_candidates_cp = increase_candidates;
    sort(increase_candidates.begin(), increase_candidates.end(), candidate_flow_cmp_greater());
}

void OptSearch::construct_first_solution_by_node_max_flow()
{

    calculate_candidates_neighbor();
    sort(candidates.begin(), candidates.end(), candidate_flow_cmp_greater());

    int num = int(node_num * 0.1);
    int cnt = 0;
    for(int i = 0; i < node_num; i++)
    {
        int node_id = candidates[i]->node_id;
        //cout<<i<<" "<<node_id<<" "<<candidates[i]->max_flow<<" "<<candidates[i]->cus_num<<endl;
        if(g_node_customer[node_id] != -1)
        {
            servers[node_id] = level_num - 1;
        }
        else
        {
            if(cnt++ < num)
            {
                servers[node_id] = level_num - 1;
            }

        }
    }

    global_min_cost = INF;
    bool is_feasible = run_max_level_mcf();
    if(!is_feasible)
    {
        cout<<"construct first solution error"<<endl;
    }
}

void OptSearch::deal_with_topo_lv0_zero()
{
    construct_first_solution_by_node_demand();
    cout<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;

}

void OptSearch::deal_with_topo_lv0_one()
{
    construct_first_solution_by_node_demand();
    reverse(candidates.begin(), candidates.end());
    decrease_server_with_max_level();
    increase_server_with_max_level();
    decrease_server_with_max_level();

    run_server_level_mcf();
    cout<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;

    //calculate_candidates_neighbor();
    //global_min_cost = zkw_mcf->cal_server_level(servers);
    //cout<<global_min_cost<<" "<<endl;
}

void OptSearch::deal_with_topo_lv0_two()
{
    construct_first_solution_by_node_max_flow();
    reverse(candidates.begin(), candidates.end());
    decrease_server_with_max_level();
    reverse(candidates.begin(), candidates.end());
    increase_server_with_max_level();
    reverse(candidates.begin(), candidates.end());
    decrease_server_with_max_level();

    run_server_level_mcf();
    cout<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;
}

void OptSearch::deal_with_topo_lv2_zero()
{
    construct_first_solution_combine_demand_and_flow();
    reverse(candidates.begin(), candidates.end());


    decrease_server_with_max_level();
    increase_server_with_max_level();
    decrease_server_with_max_level();
    down_server_level();

    //exchange_server_by_node_pass_cost_lv2();
    //down_server_level();
}

void OptSearch::topo_strategy()
{
    if(topo_lv == 0)
    {
        deal_with_topo_lv0_three();
    }
    else if(topo_lv == 1)
    {
        deal_with_topo_lv0_three();
    }
    else
    {
        deal_with_topo_lv2_zero();
    }

    run_server_level_mcf();
    cout<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;

}

void OptSearch::deal_with_topo_lv0_three()
{
    construct_first_solution_combine_demand_and_flow();
    reverse(candidates.begin(), candidates.end());


    decrease_server_with_max_level();
    increase_server_with_max_level();
    decrease_server_with_max_level();
    down_server_level();

    int best_cost;
    while(true)
    {
        best_cost = global_min_cost;
        exchange_server_by_node_pass_cost();
        down_server_level();
        if(best_cost == global_min_cost) break;
    }

    /*servers[3] = 5;
    servers[7] = 3;
    servers[14] = 4;
    servers[36] = 3;
    servers[69] = 4;
    servers[103] = 3;
    servers[125] = 3;
    servers[129] = 3;
    servers[155] = 5;
    run_max_level_mcf();*/

    //servers[69] = 4;
    //servers[38] = -1;
    //servers[103] = 4;
    //servers[130] = -1;
    //servers[7] = 5;
    //servers[36] = 3;
    //servers[120] = -1;
    /*down_server_level();
    bool is_feasible = run_server_level_mcf();
    cout<<is_feasible<<" "<<global_min_cost<<endl;*/

    //calculate_candidates_pass_cost();
    /*for(int i = 0; i < node_num; i++)
    {
        if(servers[i] == -1) continue;
        cout<<i<<": ";
        for(int j = g_node_head[i]; j != -1; j = g_edge_next[j])
            cout<<g_edge_des[j]<<" ";
        cout<<endl;
    }*/
    //cout<<global_min_cost<<endl;
    //for(int i = 0; i < node_num; i++)
        //cout<<increase_candidates[i]->node_id<<endl;
    //reverse(candidates.begin(), candidates.end());
    //decrease_server_with_max_level();

}

bool OptSearch::run_server_level_mcf()
{
    zkw_mcf->init(servers);
    bool is_feasible = zkw_mcf->run_zkw_mcf();
    if(is_feasible) update_global_min_cost();
    return is_feasible;
}

bool OptSearch::run_max_level_mcf()
{
    zkw_mcf->init(servers, 1);
    bool is_feasible = zkw_mcf->remove_run_zkw_mcf();
    global_flow_cost = zkw_mcf->min_cost;
    if(is_feasible) update_global_min_cost();
    return is_feasible;
}

void OptSearch::update_global_min_cost()
{
    memset(servers, -1, sizeof(int) * node_num);
    global_min_cost = zkw_mcf->cal_server_level(servers);
    //cout<<global_min_cost<<endl;
}

bool OptSearch::decrease_server_with_max_level()
{
    set_mcf_state();

    int best_cost = global_min_cost, begin_cost = global_min_cost;
    int node_id, *tmp, tmp_lv;
    bool is_feasible;

    int cnt = 0;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        if(servers[node_id] == -1) continue;
        //memcpy(pre_servers, servers, sizeof(int) * node_num);
        tmp_lv = servers[node_id];
        memcpy(pre_servers, servers, sizeof(int) * node_num);
        servers[node_id] = -1;

        is_feasible = remove_a_server(node_id);
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl;
        //is_feasible = zkw_mcf->remove_a_server(servers, node_id);
        //is_feasible = run_max_level_mcf();
        cnt++;
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl;
        if(is_feasible && global_min_cost < best_cost)
        {
            zkw_mcf->set_state_from_cur_state();
            best_cost = global_min_cost;
        }
        else
        {
            memcpy(servers, pre_servers, sizeof(int) * node_num);
            global_min_cost = best_cost;
        }
        //if(node_id == 150) break;
        //break;
        //cout<<i<<" "<<servers[i]<<endl;
    }
    //cout<<"cnts: "<<cnt<<endl;
    cout<<"min cost after decrease_server_with_max_level: "<<global_min_cost<<endl;
    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::increase_server_with_max_level()
{
    clock_t start = clock();

    set_mcf_state();

    int best_cost = global_min_cost, begin_cost = global_min_cost;
    int node_id, tmp_lv;
    bool is_feasible;

    int cnt = 0;
    for(int i = 0; i < node_num; i++)
    {
        if(increase_candidates[i]->node_id == -1) break;
        cnt++;
        node_id = increase_candidates[i]->node_id;
        //cout<<node_id<<endl;
        if(servers[node_id] != -1) continue;
        memcpy(pre_servers, servers, sizeof(int) * node_num);
        servers[node_id] = 0;
        //is_feasible = this->run_max_level_mcf();
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl;

        is_feasible = add_a_server(node_id);
        //is_feasible = run_max_level_mcf();
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl<<endl;
        if(is_feasible && global_min_cost < best_cost)
        {
            zkw_mcf->set_state_from_cur_state();
            best_cost = global_min_cost;
        }
        else
        {
            memcpy(servers, pre_servers, sizeof(int) * node_num);
            global_min_cost = best_cost;
        }
        //if(node_id == 150) break;
        //break;
        //cout<<i<<" "<<servers[i]<<endl;
    }
    cout<<"cnts: "<<cnt<<endl;
    cout<<"min cost after increase_server_with_max_level: "<<global_min_cost<<endl;

    clock_t end = clock();
    printf("Use Time:%f\n",(double(end-start)/CLOCKS_PER_SEC));

    if(global_min_cost < begin_cost) return true;
    return false;
}

void OptSearch::set_mcf_state(int which)
{
    //run_server_level_mcf();
    if(which == 0)  run_max_level_mcf();
    else run_server_level_mcf();
    zkw_mcf->set_state_from_cur_state();
}

bool OptSearch::remove_a_server(int server_id)
{
    bool is_feasible = zkw_mcf->remove_a_server(servers, server_id);
    if(is_feasible) update_global_min_cost();
    return is_feasible;
}

bool OptSearch::add_a_server(int server_id)
{
    bool is_feasible = zkw_mcf->zkw_increase_one_server(server_id);
    if(is_feasible) update_global_min_cost();
    return is_feasible;
}

void OptSearch::calculate_candidates_neighbor()
{
    int max_flow, cus_num, des;
    for(int i = 0; i < node_num; i++)
    {
        max_flow = 0, cus_num = 0;
        if(g_node_customer[i] != -1)
            cus_num++;
        for(int j = g_node_head[i]; j != -1; j = g_edge_next[j])
        {
            max_flow += g_edge_cap[j];
            des = g_edge_des[j];
            if(g_node_customer[des] != -1)
                cus_num++;
        }
        candidates_cp[i]->max_flow = max_flow;
        candidates_cp[i]->cus_num = cus_num;
        //cout<<i<<" "<<max_flow<<" "<<cus_num<<endl;
    }
}

bool OptSearch::down_server_level()
{
    set_mcf_state(1);

    int node_id, best_cost = global_min_cost, begin_cost = global_min_cost;
    bool changed, is_feasible;
    while(true)
    {
        calculate_candidates_overflow_cost();
        sort(candidates.begin(), candidates.end(), candidate_overflow_cmp_greater());
        changed = false;
        for(int i = 0; i < node_num; i++)
        {
            node_id = candidates[i]->node_id;
            if(candidates[i]->overflow_cost <= 0.0 || servers[node_id] == -1) break;
            //cout<<node_id<<" "<<candidates[i]->overflow_cost<<endl;
            memcpy(pre_servers, servers, sizeof(int) * node_num);
            servers[node_id]--;

            is_feasible = run_server_level_mcf();
            if(is_feasible && global_min_cost < best_cost)
            {
                best_cost = global_min_cost;
                changed = true;
                break;
            }
            else
            {
                memcpy(servers, pre_servers, sizeof(int) * node_num);
                global_min_cost = best_cost;
            }
        }
        if(!changed) break;
    }

    cout<<"min cost after down_server_level: "<<global_min_cost<<endl;
    if(global_min_cost < begin_cost) return true;
    return false;
}

void OptSearch::calculate_candidates_overflow_cost()
{
    zkw_mcf->calculate_overflow_cost(candidates_cp);
}

bool OptSearch::calculate_candidates_pass_cost()
{
    zkw_mcf->init(servers, 0);
    bool is_feasible = zkw_mcf->run_zkw_mcf_record_all_cost();
    for(int i = 0; i < node_num; i++)
    {
        candidates_cp[i]->pass_cost = mcf_cost_array[i];
        //cout<<i<<" "<<mcf_cost_array[i]<<endl;
    }
    //cout<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;
    return is_feasible;
}

bool OptSearch::exchange_server_by_node_pass_cost_lv2()
{
    //cout<<111<<endl;
    calculate_candidates_pass_cost();
    sort(candidates.begin(), candidates.end(), candidate_pass_cost_cmp_greater());

    int begin_cost = global_min_cost;
    int in_id;
    for(int i = 0; i < node_num; i++)
    {
        if(servers[i] == -1) continue;
        exchange_one_server_with_other_candidates(i);
    }

    cout<<"min cost after exchange_server_by_node_pass_cost: "<<global_min_cost<<endl;

    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::exchange_one_server_with_other_candidates(int out_id)
{
    int in_lv, ret, real_lv, in_id, cnt = 0;
    bool succeed = false;
    for(int i = 0; i < node_num; i++)
    {
        if(increase_candidates_cp[i] == empty_candidate) continue;
        if(servers[i] != -1) continue;
        cnt++;
        if(cnt >= 20) break;

        in_id = i;
        ret = exchange_node(in_id, level_num - 1, out_id, real_lv);
        if(ret == 2) continue;
        if(ret == 0)
        {
            succeed = true;
            break;
        }
        ret = exchange_node(in_id, real_lv - 1, out_id, real_lv);
        if(ret == 0) succeed = true;
        if(succeed) break;
    }

    return succeed;
}

bool OptSearch::exchange_server_by_node_pass_cost()
{
    calculate_candidates_pass_cost();
    sort(candidates.begin(), candidates.end(), candidate_pass_cost_cmp_greater());

    int begin_cost = global_min_cost;
    int in_id;
    for(int i = 0; i < node_num; i++)
    {
        in_id = candidates[i]->node_id;
        if(increase_candidates_cp[in_id] == empty_candidate) continue;
        if(servers[in_id] != -1) continue;
        exchange_one_node_with_all_server(in_id);
    }

    cout<<"min cost after exchange_server_by_node_pass_cost: "<<global_min_cost<<endl;

    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::exchange_one_node_with_all_server(int in_id)
{
    int in_lv, ret, real_lv, out_id;
    bool succeed = false;
    for(int i = 0; i < node_num; i++)
    {
        if(servers[i] == -1) continue;
        out_id = i;
        ret = exchange_node(in_id, level_num - 1, out_id, real_lv);
        if(ret == 2) continue;
        if(ret == 0)
        {
            succeed = true;
            break;
        }
        ret = exchange_node(in_id, real_lv - 1, out_id, real_lv);
        if(ret == 0) succeed = true;
        if(succeed) break;
    }

    return succeed;
}

int OptSearch::exchange_node(int in_id, int in_lv, int out_id, int& real_lv)
{
    if(servers[in_id] != -1 || servers[out_id] == -1)
    {
        cout<<"exchange_node error"<<endl;
        return 2;
    }

    int best_cost = global_min_cost;
    int tmp_lv = servers[out_id];

    memcpy(pre_servers, servers, sizeof(int) * node_num);

    servers[in_id] = in_lv;
    servers[out_id] = -1;

    bool is_feasible = run_server_level_mcf();

    if(is_feasible)
    {
        real_lv = servers[in_id];
        if(global_min_cost < best_cost)
        {
            return 0;
        }
        else
        {
            memcpy(servers, pre_servers, sizeof(int) * node_num);
            global_min_cost = best_cost;
            return 1;
        }
    }
    else
    {
        servers[out_id] = tmp_lv;
        servers[in_id] = -1;
        global_min_cost = best_cost;
        return 2;
    }

}
#endif
