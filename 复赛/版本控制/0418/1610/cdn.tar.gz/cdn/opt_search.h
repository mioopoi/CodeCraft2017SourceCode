#ifndef __OPT_SEARCH_H__
#define __OPT_SEARCH_H__

#include <iostream>
#include <vector>
#include <algorithm>

#include "opt_search_helper.h"
#include "graph.h"
#include "net_simplex_mcf.h"

#define MAX_LEVEL_FLOW_COST 0
#define SERVER_LEVEL_FLOW_COST 1
#define ONLY_RUN 2
#define NO_UPDATE_LEVEL 3

class OptSearch
{
public:
    Graph* graph;
    NetSimplexMCF* mcf_simplex;
    int node_num;
    int customer_num;
    int level_num;

    vector<Candidate*> candidates;
    vector<Candidate*> candidates_cp;
    Candidate* candidate_start_ptr;

    int global_min_cost;
    int* servers;
    int* pre_servers;
    Candidate* empty_candidate;
    int topo_lv;
    vector<vector<ServerCost>> supply_costs;

public:
    OptSearch(Graph* graph);
    void init_candidates();
    bool show_detail_info();
    int mcf_cnt;
    int start_time;
    int end_time;

public:
    void init_supply_costs();
    void calculate_candidates_neighbor();
    void calculate_candidate_out_flow();
    bool calculate_candidates_pass_cost();
    bool calculate_candidates_pass_flow();
    bool calculate_server_cost(vector<ServerCost>& server_costs);

    int choose_server_by_node_demand(double percent);
    int choose_server_by_node_max_flow(bool re_cal, double percent);

    void construct_first_solution_combine_demand_and_flow();
    void construct_first_solution_by_min_server_cost();

public:
    bool run_simplex_mcf(int run_type);
public:
    void deal_with_topo_lv0_zero();
    void deal_with_topo_lv0_one();
public:
    bool decrease_server_by_server_outflow_max_level();
    bool decrease_server_by_server_out_flow_no_adjust_level();
    bool decrease_server_by_server_outflow();

    bool increase_server_by_node_pass_cost_max_level();
    bool increase_server_by_node_pass_cost_no_adjust_level();

    int exchange_node_no_adjust_level(int in_id, int in_lv, int out_id);
    bool exchange_server_by_server_cost_no_adjust_level();
    bool exchange_server_with_neighbor_no_adjust_level();
    bool exchange_server_by_node_pass_cost_no_adjust_level();
    bool exchange_one_server_with_other_candidates_no_adjust_level(int out_id);
};

OptSearch::OptSearch(Graph* graph)
{
    this->graph = graph;
    mcf_simplex = new NetSimplexMCF(graph);
    node_num = graph->node_num;
    customer_num =graph->customer_num;
    level_num = graph->level_num;

    servers = new int[node_num];
    pre_servers = new int[node_num];

    memset(servers, -1, sizeof(int) * node_num);

    global_min_cost = INF;
    init_candidates();

    if(node_num < 200) topo_lv = 0;
    else if(node_num < 500) topo_lv = 1;
    else topo_lv = 2;

    mcf_cnt = 0;
}

void OptSearch::init_candidates()
{
    int candidate_ptr_cnt = 0;
    candidate_start_ptr = new Candidate[node_num + 2];

    empty_candidate = new (candidate_start_ptr + candidate_ptr_cnt) Candidate();
    candidate_ptr_cnt++;

    candidates = vector<Candidate*>(node_num, NULL);
    candidates_cp = vector<Candidate*>(node_num, NULL);

    bool is_customer;
    int demand;
    for(int i = 0; i < node_num; i++)
    {
        if(g_node_customer[i] != -1)
        {
            is_customer = true;
            demand = g_customer_need[g_node_customer[i]];
        }
        else
        {
            is_customer = false;
            demand = 0;
        }
        candidates[i] = new (candidate_start_ptr + candidate_ptr_cnt) Candidate(i, demand, g_node_cost[i]);
        candidates_cp[i] = candidates[i];
        candidate_ptr_cnt++;
    }
}

void OptSearch::init_supply_costs()
{
    supply_costs = vector<vector<ServerCost>>(node_num, vector<ServerCost>(0));
    for(int i = 0; i < node_num; i++)
    {
        for(int j = 0; j < node_num; j++)
        {
            if(simplex_cost_matrix_cp[i][j] != INF)
            {
                supply_costs[j].push_back(ServerCost(i, j, simplex_cost_matrix_cp[i][j]));
                //cout<<i<<" "<<j<<" "<<simplex_cost_matrix_cp[i][j]<<endl;
            }
        }
    }

    for(int i = 0; i < node_num; i++)
    {
        sort(supply_costs[i].begin(), supply_costs[i].end(), server_cost_cmp_less());
    }

}

void OptSearch::calculate_candidates_neighbor()
{
    int max_flow, cus_num, des;
    for(int i = 0; i < node_num; i++)
    {
        max_flow = 0, cus_num = 0;
        if(g_node_customer[i] != -1)
            cus_num++;
        for(int j = g_node_head[i]; j != -1; j = g_edge_next[j])
        {
            max_flow += g_edge_cap[j];
            des = g_edge_des[j];
            if(g_node_customer[des] != -1)
                cus_num++;
        }
        candidates_cp[i]->max_flow = max_flow;
        candidates_cp[i]->cus_num = cus_num;
        //cout<<i<<" "<<max_flow<<" "<<cus_num<<endl;
    }
}

void OptSearch::calculate_candidate_out_flow()
{
    for(int i = 0; i < node_num; i++)
    {
        candidates_cp[i]->server_out_flow = 0;
    }
    run_simplex_mcf(2);
    mcf_simplex->calculate_server_out_flow(candidates_cp);
    //zkw_mcf->calculate_server_flow(candidates_cp);
    sort(candidates.begin(), candidates.end(), candidate_server_out_flow_cmp_less());
    /*for(int i = 0; i < node_num; i++)
    {
        cout<<candidates[i]->node_id<<" "<<candidates[i]->server_out_flow<<endl;
    }*/

}

bool OptSearch::calculate_candidates_pass_cost()
{
    run_simplex_mcf(ONLY_RUN);
    mcf_simplex->calculate_node_pass_flow();
    for(int i = 0; i < node_num; i++)
    {
        candidates_cp[i]->pass_cost = simplex_cost_array[i];
        //cout<<i<<" "<<simplex_cost_array[i]<<endl;
    }
    //cout<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;
    return true;
}

bool OptSearch::calculate_candidates_pass_flow()
{
    run_simplex_mcf(ONLY_RUN);
    mcf_simplex->calculate_node_pass_flow();
    for(int i = 0; i < node_num; i++)
    {
        candidates_cp[i]->pass_flow = simplex_flow_array[i];
        //cout<<i<<" "<<simplex_cost_array[i]<<endl;
    }
    //cout<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;
    return true;
}

bool OptSearch::calculate_server_cost(vector<ServerCost>& server_costs)
{
    mcf_simplex->init_simplex_cost_matrix();
    run_simplex_mcf(ONLY_RUN);
    mcf_simplex->calculate_server_supply();

    for(int i = 0; i < node_num; i++)
    {
        if(servers[i] == -1) continue;
        for(int j = 0; j < node_num; j++)
        {
            if(simplex_flow_matrix[i][j])
            {
                server_costs.push_back(ServerCost(i, j, simplex_cost_matrix[i][j]));
                //cout<<i<<" "<<j<<" "<<simplex_cost_matrix[i][j]<<endl;
            }
        }
    }
    sort(server_costs.begin(), server_costs.end(), server_cost_cmp_greater());

    /*if(tag == 0)
    {
        for(int i = 0; i < server_costs.size(); i++)
        {
            cout<<server_costs[i].server_id<<" "<<server_costs[i].customer_id<<" "<<server_costs[i].cost<<endl;
        }
    }*/
}

int OptSearch::choose_server_by_node_demand(double percent)
{
    sort(candidates.begin(), candidates.end(), candidate_demand_cmp_greater());

    int cus_num = int(customer_num * percent);
    int cus_cnt = 0, node_id;
    for(int i = 0; i < cus_num; i++)
    {
        node_id = candidates[i]->node_id;
        servers[node_id] = level_num - 1;
    }

    //sort(increase_candidates.begin(), increase_candidates.end(), candidate_demand_cmp_greater());
    //for(int i = 0; i < node_num; i++)
    //cout<<increase_candidates[i]->node_id<<endl;
    return cus_num;
}

int OptSearch::choose_server_by_node_max_flow(bool re_cal, double percent)
{
    if(re_cal)  calculate_candidates_neighbor();
    sort(candidates.begin(), candidates.end(), candidate_flow_cmp_greater());

    int middle_num = int(node_num * percent);
    int node_id;
    for(int i = 0; i < middle_num; i++)
    {
        node_id = candidates[i]->node_id;
        servers[node_id] = level_num - 1;
    }
    return middle_num;
}

void OptSearch::construct_first_solution_combine_demand_and_flow()
{
    double p0 = 0.1, p1 = 0.1;
    choose_server_by_node_demand(p0);
    choose_server_by_node_max_flow(true, p1);
    bool is_feasible = run_simplex_mcf(MAX_LEVEL_FLOW_COST);
    cout<<is_feasible<<" "<<global_min_cost<<endl;
    while(!is_feasible)
    {
        p0 += 0.1;
        p1 += 0.1;
        cout<<p0<<" "<<p1<<endl;
        choose_server_by_node_demand(p0);
        choose_server_by_node_max_flow(false, p1);
        memcpy(pre_servers, servers, sizeof(int) * node_num);
        is_feasible = run_simplex_mcf(MAX_LEVEL_FLOW_COST);
        cout<<is_feasible<<" "<<global_min_cost<<endl;
    }
}

void OptSearch::construct_first_solution_by_min_server_cost()
{
    int max_lv_cost = g_server_level[level_num - 1].cost;

    memset(servers, -1, sizeof(int) * node_num);
    for(int i = 0; i < node_num; i++)
    {
        servers[i] = level_num - 1;
        run_simplex_mcf(ONLY_RUN);
        //cout<<mcf_simplex->min_cost<<" "<<mcf_simplex->max_flow<<endl;
        mcf_simplex->calculate_server_supply();
        servers[i] = -1;
    }

    for(int i = 0; i < node_num; i++)
    {
        int max_flow = 0;
        for(int j = 0; j < node_num; j++)
        {
            if(simplex_flow_matrix[i][j] != 0 && simplex_flow_matrix[i][j] == g_customer_need[g_node_customer[j]])
            {
                simplex_cost_matrix_cp[i][j] = simplex_cost_matrix[i][j];
            }
            else
            {
                simplex_cost_matrix_cp[i][j] = INF;
            }

            if(simplex_flow_matrix[i][j] != 0 && simplex_flow_matrix[i][j] == g_customer_need[g_node_customer[j]]
                && simplex_cost_matrix[i][j] < max_lv_cost)
            {
                max_flow += simplex_flow_matrix[i][j];
            }
            else
            {
                simplex_cost_matrix[i][j] = INF;
                simplex_flow_matrix[i][j] = 0;
            }
        }
        if(max_flow == 0) continue;
        for(int j = 0; j < node_num; j++)
        {
            if(simplex_flow_matrix[i][j] == 0) continue;
            simplex_cost_matrix[i][j] += 1.0 * max_lv_cost / max_flow * simplex_flow_matrix[i][j];
            //cout<<i<<" "<<" "<<j<<" "<<mcf_cost_matrix[i][j]<<" "<<mcf_flow_matrix[i][j]<<" "<<max_flow<<endl;
        }
    }

    int server_id;
    for(int j = 0; j < node_num; j++)
    {
        if(g_node_customer[j] == -1) continue;

        vector<pair<int, int>> myarray;
        for(int i = 0; i < node_num; i++)
        {
            if(simplex_cost_matrix[i][j] != INF)
                myarray.push_back(make_pair(simplex_cost_matrix[i][j], i));
        }
        sort(myarray.begin(), myarray.end());
        for(int i = 0; i < 2 && i < myarray.size(); i++)
        {
            server_id = myarray[i].second;
            servers[server_id] = level_num - 1;
            //cout<<j<<" "<<myarray[i].first<<" "<<myarray[i].second<<" "<<endl;
        }
        if(myarray.size() == 0)
        {
            servers[j] = level_num - 1;
        }
    }

    /*int cnt = 0;
    for(int i = 0; i < node_num; i++)
    {
        if(servers[i] != -1)
        {
            //cnt++;
            cout<<i<<" ";
        }
    }
    cout<<cnt<<endl;*/

    bool is_feasible = run_simplex_mcf(NO_UPDATE_LEVEL);
    if(is_feasible)
    {
        cout<<"construct succeed!!!"<<" "<<global_min_cost<<endl;
    }
    else
    {
        global_min_cost = INF;
    }

    init_supply_costs();
}
//update_type 0 最大等级跑，按流量更新服务器
//run_type  1    服务器等级跑，按更新更新服务器
//run type  2   服务器等级跑，不做更新

bool OptSearch::run_simplex_mcf(int run_type)
{
    mcf_cnt++;
    bool is_feasible;
    if(run_type == MAX_LEVEL_FLOW_COST)
    {
        mcf_simplex->init(this->servers, 1);
        is_feasible = mcf_simplex->solve();

        if(is_feasible)
        {
            memset(servers, -1, sizeof(int) * node_num);
            global_min_cost = mcf_simplex->calculate_total_cost(servers, 0);
        }
    }
    else if(run_type == SERVER_LEVEL_FLOW_COST)
    {
        mcf_simplex->init(this->servers, 0);
        is_feasible = mcf_simplex->solve();
        if(is_feasible)
        {
            memset(servers, -1, sizeof(int) * node_num);
            global_min_cost = mcf_simplex->calculate_total_cost(servers, 0);
        }
    }
    else if(run_type == ONLY_RUN)
    {
        mcf_simplex->init(this->servers, 0);
        is_feasible = mcf_simplex->solve();
    }
    else if(run_type == NO_UPDATE_LEVEL)
    {
        mcf_simplex->init(this->servers, 0);
        is_feasible = mcf_simplex->solve();
        if(is_feasible)
        {
            global_min_cost = mcf_simplex->calculate_total_cost(servers, 1);
        }
    }

    return is_feasible;
}

void OptSearch::deal_with_topo_lv0_zero()
{
    construct_first_solution_combine_demand_and_flow();
    for(int i = 0; i < node_num; i++)
    {
        if(servers[i] != -1) servers[i] = level_num - 1;
    }
    run_simplex_mcf(NO_UPDATE_LEVEL);
    decrease_server_by_server_out_flow_no_adjust_level();
    //decrease_server_by_server_outflow_max_level();
    //increase_server_by_node_pass_flow_max_level();
    //show_detail_info();
    //memcpy(servers, pre_servers, sizeof(int) * node_num);
    bool is_feasible = run_simplex_mcf(1);
    cout<<is_feasible<<" "<<global_min_cost<<endl;
    //show_detail_info();
    cout<<"mcf_cnt: "<<mcf_cnt<<endl;
}

void OptSearch::deal_with_topo_lv0_one()
{
    construct_first_solution_by_min_server_cost();
    decrease_server_by_server_out_flow_no_adjust_level();

    /*exchange_server_by_server_cost_no_adjust_level();
    exchange_server_with_neighbor_no_adjust_level();
    exchange_server_by_node_pass_cost_no_adjust_level();
    increase_server_by_node_pass_cost_no_adjust_level();
    decrease_server_by_server_out_flow_no_adjust_level();

    run_simplex_mcf(SERVER_LEVEL_FLOW_COST);
    decrease_server_by_server_outflow();*/


    bool is_feasible = run_simplex_mcf(SERVER_LEVEL_FLOW_COST);
    cout<<is_feasible<<" "<<global_min_cost<<endl;
}

bool OptSearch::show_detail_info()
{

    for(int i = 0; i < node_num; i++)
    {
        if(servers[i] != -1)
        {
            cout<<i<<" "<<servers[i]<<endl;
        }
    }
    cout<<endl<<"min cost: "<<global_min_cost<<endl;

}

bool OptSearch::decrease_server_by_server_outflow_max_level()
{
    calculate_candidate_out_flow();

    int best_cost = global_min_cost, begin_cost = global_min_cost;
    int node_id, tmp_lv;
    bool is_feasible;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        if(servers[node_id] == -1) continue;

        memcpy(pre_servers, servers, sizeof(int) * node_num);

        servers[node_id] = -1;
        is_feasible = run_simplex_mcf(0);
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<zkw_mcf->max_flow<<" "<<global_min_cost<<endl;

        if(is_feasible && global_min_cost < best_cost)
        {
            best_cost = global_min_cost;
        }
        else
        {
            memcpy(servers, pre_servers, sizeof(int) * node_num);
            global_min_cost = best_cost;
        }
        //break;
    }

    cout<<"min cost after decrease_server_by_server_outflow_max_level: "<<global_min_cost<<endl;
    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::decrease_server_by_server_out_flow_no_adjust_level()
{
    calculate_candidate_out_flow();

    int best_cost = global_min_cost, begin_cost = global_min_cost;
    int node_id, tmp_lv;
    bool is_feasible;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        if(servers[node_id] == -1) continue;

        tmp_lv = servers[node_id];
        servers[node_id] = -1;
        is_feasible = run_simplex_mcf(NO_UPDATE_LEVEL);
        //cout<<node_id<<" "<<is_feasible<<" "<<mcf_simplex->min_cost<<" "<<mcf_simplex->max_flow<<" "<<global_min_cost<<endl;

        if(is_feasible && global_min_cost < best_cost)
        {
            best_cost = global_min_cost;
        }
        else
        {
            servers[node_id] = tmp_lv;
            global_min_cost = best_cost;
        }
        //break;
    }

    cout<<"min cost after decrease_server_by_server_out_flow_no_adjust_level: "<<global_min_cost<<endl;
    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::decrease_server_by_server_outflow()
{
    calculate_candidate_out_flow();

    int best_cost = global_min_cost, begin_cost = global_min_cost;
    int node_id, tmp_lv;
    bool is_feasible;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        if(servers[node_id] == -1) continue;

        memcpy(pre_servers, servers, sizeof(int) * node_num);
        is_feasible = run_simplex_mcf(SERVER_LEVEL_FLOW_COST);

        if(is_feasible && global_min_cost < best_cost)
        {
            best_cost = global_min_cost;
        }
        else
        {
            memcpy(servers, pre_servers, sizeof(int) * node_num);
            global_min_cost = best_cost;
        }
        //break;
    }

    cout<<"min cost after decrease_server_by_server_out_flow: "<<global_min_cost<<endl;
    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::increase_server_by_node_pass_cost_max_level()
{
    calculate_candidates_pass_cost();
    sort(candidates.begin(), candidates.end(), candidate_pass_cost_cmp_greater());

    int best_cost = global_min_cost, begin_cost = global_min_cost;
    int node_id;
    bool is_feasible;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        if(servers[node_id] != -1) continue;

        memcpy(pre_servers, servers, sizeof(int) * node_num);

        servers[node_id] = level_num - 1;
        is_feasible = run_simplex_mcf(0);
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl;

        if(is_feasible && global_min_cost < best_cost)
        {
            best_cost = global_min_cost;
        }
        else
        {
            memcpy(servers, pre_servers, sizeof(int) * node_num);
            global_min_cost = best_cost;
        }
    }
    cout<<"min cost after increase_server_by_node_pass_flow_max_level: "<<global_min_cost<<endl;

    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::increase_server_by_node_pass_cost_no_adjust_level()
{
    calculate_candidates_pass_cost();
    sort(candidates.begin(), candidates.end(), candidate_pass_cost_cmp_greater());

    int best_cost = global_min_cost, begin_cost = global_min_cost;
    int node_id;
    bool is_feasible;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        if(servers[node_id] != -1) continue;

        servers[node_id] = level_num - 1;
        is_feasible = run_simplex_mcf(NO_UPDATE_LEVEL);
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl;

        if(is_feasible && global_min_cost < best_cost)
        {
            best_cost = global_min_cost;
        }
        else
        {
            servers[node_id] = -1;
            global_min_cost = best_cost;
        }
    }
    //cout<<"min cost after increase_server_by_node_pass_flow: "<<global_min_cost<<endl;

    if(global_min_cost < begin_cost) return true;
    return false;
}

int OptSearch::exchange_node_no_adjust_level(int in_id, int in_lv, int out_id)
{
    if(servers[in_id] != -1 || servers[out_id] == -1)
    {
        cout<<"exchange_node error"<<endl;
        return 2;
    }

    int best_cost = global_min_cost;
    int tmp_lv = servers[out_id];

    servers[in_id] = in_lv;
    servers[out_id] = -1;

    bool is_feasible = run_simplex_mcf(NO_UPDATE_LEVEL);

    if(is_feasible)
    {
        if(global_min_cost < best_cost)
        {
            return 0;
        }
        else
        {

            servers[out_id] = tmp_lv;
            servers[in_id] = -1;
            global_min_cost = best_cost;
            return 1;
        }
    }
    else
    {
        servers[out_id] = tmp_lv;
        servers[in_id] = -1;
        global_min_cost = best_cost;
        return 2;
    }

}

bool OptSearch::exchange_one_server_with_other_candidates_no_adjust_level(int out_id)
{
    int up;
    if(topo_lv == 0) up = 20;
    else if(topo_lv == 1) up = 20;
    else up = 20;

    int in_lv, ret, real_lv, in_id, cnt = 0;
    bool succeed = false;
    for(int i = 0; i < node_num; i++)
    {
        //if(increase_candidates_cp[i] == empty_candidate) continue;
        in_id = candidates[i]->node_id;
        if(servers[in_id] != -1) continue;
        if(topo_lv <= 2)
        {
            cnt++;
            if(cnt >= up) break;
        }

        ret = exchange_node_no_adjust_level(in_id, servers[out_id], out_id);
        if(ret == 2 || ret == 1) continue;
        if(ret == 0)
        {
            succeed = true;
            break;
        }
        //ret = exchange_node(in_id, real_lv - 1, out_id, real_lv);
        //if(ret == 0) succeed = true;
        if(succeed) break;
    }

    return succeed;
}

bool OptSearch::exchange_server_by_server_cost_no_adjust_level()
{
    int best_cost = global_min_cost, begin_cost = global_min_cost;

    vector<ServerCost> server_costs;
    calculate_server_cost(server_costs);

    int server_id, customer_id, in_id, ret, min_in_id, tmp_cost, tmp_lv;
    bool exchange;
    for(int i = 0; i < server_costs.size(); i++)
    {
        server_id = server_costs[i].server_id;
        customer_id = server_costs[i].customer_id;
        if(servers[server_id] == -1) continue;

        min_in_id = -1;
        tmp_cost = global_min_cost;
        tmp_lv = servers[server_id];
        exchange = false;

        for(int j = 0; j < supply_costs[customer_id].size(); j++)
        {
            in_id = supply_costs[customer_id][j].server_id;
            if(servers[in_id] != -1) continue;

            ret = exchange_node_no_adjust_level(in_id, servers[server_id], server_id);

            if(ret == 0 && global_min_cost < best_cost)
            {
                best_cost = global_min_cost;
                min_in_id = in_id;
                exchange = true;
            }

            servers[server_id] = tmp_lv;
            servers[in_id] = -1;
            global_min_cost = tmp_cost;
        }

        if(min_in_id != -1)
        {
            //cout<<min_in_id<<" "<<server_id<<endl;
            servers[min_in_id] = tmp_lv;
            servers[server_id] = -1;
            global_min_cost = best_cost;
        }
        if(exchange) break;
    }

    cout<<"min cost after exchange_server_by_server_cost_no_adjust_level: "<<global_min_cost<<endl;
    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::exchange_server_with_neighbor_no_adjust_level()
{
    int best_cost = global_min_cost, begin_cost = global_min_cost;
    int in_id, out_id, ret, lv;
    for(int i = 0; i < node_num; i++)
    {
        if(servers[i] == -1) continue;
        out_id = i;
        for(int j = g_node_head[i]; j != -1; j = g_edge_next[j])
        {
            in_id = g_edge_des[j];
            if(servers[in_id] != -1) continue;
            ret = exchange_node_no_adjust_level(in_id, servers[out_id], out_id);
            if(ret == 0) break;
        }
    }

    cout<<"min cost after exchange_server_with_neighbor_no_adjust_level: "<<global_min_cost<<endl;

    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::exchange_server_by_node_pass_cost_no_adjust_level()
{
    //cout<<111<<endl;
    calculate_candidates_pass_cost();
    sort(candidates.begin(), candidates.end(), candidate_pass_cost_cmp_greater());

    int begin_cost = global_min_cost;
    for(int i = 0; i < node_num; i++)
    {
        if(servers[i] == -1) continue;
        exchange_one_server_with_other_candidates_no_adjust_level(i);
    }

    cout<<"min cost after exchange_server_by_node_pass_cost_no_adjust_level: "<<global_min_cost<<endl;

    if(global_min_cost < begin_cost) return true;
    return false;
}

#endif // __OPT_SEARCH_H__
