#!/bin/bash

#mycase="topo.txt"
#result="topo_result.txt"

mycase="case0.txt"
result="result0.txt"

rm cdn.tar.gz

./build.sh

cd ./bin


./cdn ../../case_example/6/$mycase ../../case_result/6/$result