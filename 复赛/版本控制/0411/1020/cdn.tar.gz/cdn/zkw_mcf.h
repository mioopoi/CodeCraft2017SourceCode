#ifndef __ZKW_MCF_H__
#define __ZKW_MCF_H__

#include <iostream>
#include <cstdio>
#include <cstring>
#include <queue>
#include <stack>

#include "graph.h"

using namespace std;

#define MIN(a,b) (a) < (b) ? (a) : (b)

const int MAX_MCF_EDGE = MAX_EDGE_NUMBER * 2;

int head[MAX_NODE_NUMBER];
int pre[MAX_NODE_NUMBER];
int dis[MAX_NODE_NUMBER];
bool vis[MAX_NODE_NUMBER];

int edge_des[MAX_MCF_EDGE];
int edge_next[MAX_MCF_EDGE];
int edge_ori_cap[MAX_MCF_EDGE];
int edge_cap[MAX_MCF_EDGE];
int edge_cost[MAX_MCF_EDGE];
int edge_flow[MAX_MCF_EDGE];
int edge_ori_cost[MAX_MCF_EDGE];

int head_cp[MAX_NODE_NUMBER];
int edge_des_cp[MAX_MCF_EDGE];
int edge_next_cp[MAX_MCF_EDGE];
int edge_ori_cap_cp[MAX_MCF_EDGE];
int edge_cap_cp[MAX_MCF_EDGE];
int edge_flow_cp[MAX_MCF_EDGE];
int edge_ori_cost_cp[MAX_MCF_EDGE];
int tol_cp;
int min_cost_cp;

class ZkwMcf
{
public:
    int source;    // 超源点
    int sink;      // 超汇点
    int tol;       // 计数变量
    int node_num;         // 节点总数量（包括超源点和超汇点）
    int edge_num;         // 有向边总数量（不包括虚拟边）
    int max_edge_num;

    int min_cost;  // 最小费用
    int max_flow;  // 最大流
    int sum_demand;

    Graph* graph;  // 原图

    ZkwMcf(Graph *graph);

    void add_edge(int src, int des, int cap, int cost);
    void init(int* servers, int level = 0);
    ~ZkwMcf();

    /* zkw */
    int min_delta_cost;
    int zkw_aug(int src, int flow);
    bool run_zkw_mcf();
    bool zkw_modlabel();
    /* */

    int cal_server_level(int* servers);
    void construct_solution(vector<vector<int>>& paths, int* servers);

    int remove_source;
    int remove_sink;
    void remove_spfa();
    int remove_zkw_aug(int src, int flow);
    bool remove_run_zkw_mcf(int which = 0);
    bool remove_zkw_modlabel();
    bool remove_a_server(int* servers, int server_id);
    void recover_state_from_cp();
    void set_state_from_cur_state();

};

ZkwMcf::ZkwMcf(Graph* graph)
{
    //cout << "Hello MinCostFlow!"<< endl;
    this->graph = graph;
    this->source = graph->node_num;   // 添加超源点
    this->sink = graph->node_num + 1; // 添加超汇点
    this->tol = 0;
    this->node_num = graph->node_num + 2;
    this->min_cost = INF;
    this->max_flow = 0;
    this->sum_demand = 0;

    memset(head, -1, sizeof(head));

    for (int i = 0; i < graph->edge_num * 2; i++)
    {
        this->add_edge(g_edge_src[i], g_edge_des[i], g_edge_cap[i], g_edge_cost[i]);
    }
    // 添加有向边：所有demand节点->超汇点
    for(int i = 0; i < graph->node_num; i++)
    {
        if(g_node_customer[i] == -1) continue;
        this->add_edge(i, sink, g_customer_need[g_node_customer[i]], 0);
        this->sum_demand += g_customer_need[g_node_customer[i]];
        //cout<<i<<" "<<g_customer_need[g_node_customer[i]]<<endl;
    }
    //cout << "total edges: " << tol << endl;
}

void ZkwMcf::add_edge(int src, int des, int cap, int cost)
{

	edge_des[tol] = des;
	edge_next[tol] = head[src];
	edge_ori_cap[tol] = cap;
	edge_cap[tol] = cap;
	edge_cost[tol] = cost;
	edge_ori_cost[tol] = cost;
	edge_flow[tol] = 0;
    head[src] = tol++;

	edge_des[tol] = src;
	edge_next[tol] = head[des];
	edge_ori_cap[tol] = 0;
	edge_cap[tol] = 0;
	edge_cost[tol] = -cost;
	edge_ori_cost[tol] = -cost;
	edge_flow[tol] = 0;
    head[des] = tol++;

}

void ZkwMcf::init(int* servers, int level)
{
        // 参数重置
    this->min_cost = INF;
    this->max_flow = 0;
    for (int i = 0; i < this->tol; ++i)
    {
        edge_cap[i] = edge_ori_cap[i];
        edge_cost[i] = edge_ori_cost[i];
        edge_flow[i] = 0;
    }
    this->tol = (this->graph->edge_num * 2 + this->graph->customer_num) * 2;

    for (int edge_id = head[source]; edge_id != -1; edge_id = edge_next[edge_id])
    {
        int des = edge_des[edge_id];
        if (head[des] != -1)
        {
			head[des] = edge_next[head[des]];
        }
    }
    head[source] = -1;


    int cnt = 0, power = g_server_level[graph->level_num - 1].power;
    // 添加有向边：超源点->所有supply节点
    for (int i = 0; i < graph->node_num; ++i)
    {
        if (servers[i] != -1)  // 节点i是supply节点
        {
            if(level == 0)
                this->add_edge(this->source, i, g_server_level[servers[i]].power, 0);
            else
            {
                this->add_edge(this->source, i, power, 0);
            }
            //cnt += g_server_level[i].power;
        }
    }
}

int ZkwMcf::zkw_aug(int src, int flow)
{
    if(src == this->sink)
    {
        this->min_cost += this->min_delta_cost * flow;
        this->max_flow += flow;
        return flow;
    }
    vis[src] = 1;
    int tmp = flow;
    for(int i = head[src]; i != -1; i = edge_next[i])
        if(edge_cap[i] && !edge_cost[i] && !vis[edge_des[i]])
        {
            int delta = zkw_aug(edge_des[i], tmp < edge_cap[i] ? tmp : edge_cap[i]);
			edge_cap[i] -= delta;
            edge_flow[i] += delta;
            edge_cap[i^1] += delta;
            edge_flow[i^1] -= delta;
            tmp -= delta;
            if(!tmp) return flow;
        }
    return flow - tmp;
}

bool ZkwMcf::zkw_modlabel()
{
    int delta = INF;
    for(int u = 0; u < this->node_num; u++)
    {
        if(!vis[u]) continue;
        for(int i = head[u]; i != -1; i = edge_next[i])
            if(edge_cap[i] && !vis[edge_des[i]] && edge_cost[i] < delta)
                delta = edge_cost[i];
    }

    if(delta == INF) return false;
    for(int u = 0; u < this->node_num; u++)
    {
        if(!vis[u]) continue;
        for(int i = head[u]; i != -1; i = edge_next[i])
            edge_cost[i] -= delta, edge_cost[i^1] += delta;
    }
    this->min_delta_cost += delta;
    return true;
}

bool ZkwMcf::run_zkw_mcf()
{
    this->min_cost = 0;
    this->max_flow = 0;
    this->min_delta_cost = 0;
    //delta_costs[delta_cnt++] = min_delta_cost;

    do
    {
        do
        {
            memset(vis, 0, sizeof(vis));
        } while(zkw_aug(this->source, INF));
    } while(zkw_modlabel());

    return this->max_flow == this->sum_demand;
}

ZkwMcf::~ZkwMcf()
{
    /*for(int i = 0; i < this->node_num; i++)
    {
        delete this->cost_matrix[i];
    }*/
}

void ZkwMcf::construct_solution(vector<vector<int>>& paths, int* servers)
{
    vector<int> edge_path(node_num + 2, -1);
    int flow_cnt = 0, last;
    while(true)
    {
        int flow = INF, cur = source, des, cnt = 0;
        while(cur != sink)
        {
            for(int i = head[cur]; i != -1; i = edge_next[i])
            {
                if(edge_flow[i] <= 0) continue;
                if(edge_flow[i] < flow) flow = edge_flow[i];
                edge_path[cnt++] = i;
                cur = edge_des[i];
                break;
            }
            if(cur == source) break;
        }
        if(flow == INF) break;
        vector<int> path(cnt + 2, 0);
        for(int i = 0; i < cnt; i++)
        {
            //flow_cnt += flow;
            edge_flow[edge_path[i]] -= flow;
            path[i] = edge_des[edge_path[i]];
        }
        flow_cnt += flow;
        last = path[cnt - 2];
        int server_id = path[0];
        path[cnt + 1] = servers[server_id];
        path[cnt] = flow;
        path[cnt - 1] = g_node_customer[last];
        paths.push_back(path);

    }
    cout<<"flow cnt: "<<flow_cnt<<endl;
}

int ZkwMcf::cal_server_level(int* servers)
{
    int total_cost = min_cost, server, level;
    for (int edge_id = head[source]; edge_id != -1; edge_id = edge_next[edge_id])
    {
        if(edge_flow[edge_id] <= 0) continue;
        server = edge_des[edge_id];
        level = g_server_level_index[edge_flow[edge_id]];
        servers[server] = level;
        total_cost += (g_node_cost[server] + g_server_level[level].cost);
    }
    return total_cost;
}

bool ZkwMcf::remove_a_server(int* servers, int server_id)
{
    recover_state_from_cp();
    remove_source = node_num;
    remove_sink = node_num + 1;

    int des, cap = 0;
    for (int edge_id = head[source]; edge_id != -1; edge_id = edge_next[edge_id])
    {
        des = edge_des[edge_id];
        if(des == server_id && edge_flow[edge_id] > 0)
        {
            cap = edge_flow[edge_id];
            edge_cap[edge_id] = 0;
            edge_flow[edge_id] = 0;
            edge_cap[edge_id^1] = 0;
            edge_flow[edge_id^1] = 0;
            break;
        }
    }

    this->add_edge(remove_source, source, cap, 0);
    this->add_edge(server_id, remove_sink, cap, 0);
    remove_run_zkw_mcf(1);
    //cout<<endl<<des<<" "<<cap<<" "<<max_flow<<" "<<min_cost<<endl;
    //cout<<"new min cost: "<<min_cost<<endl;
    head[des] = edge_next[head[des]];
    head[source] = edge_next[head[source]];
    head[remove_source] = -1;
    head[remove_sink] = -1;
    tol -= 4;
    //head[source] = -1;
    return cap == max_flow;
}

void ZkwMcf::recover_state_from_cp()
{
    tol = tol_cp;
    min_cost = min_cost_cp;
    memcpy(head, head_cp, sizeof(int) * node_num);
    memcpy(edge_des, edge_des_cp, sizeof(int) * tol);
    memcpy(edge_next, edge_next_cp, sizeof(int) * tol);
    memcpy(edge_ori_cap, edge_ori_cap_cp, sizeof(int) * tol);
    memcpy(edge_cap, edge_cap_cp, sizeof(int) * tol);
    memcpy(edge_flow, edge_flow_cp, sizeof(int) * tol);
    memcpy(edge_ori_cost, edge_ori_cost_cp, sizeof(int) * tol);
}

void ZkwMcf::set_state_from_cur_state()
{
    tol_cp = tol;
    min_cost_cp = min_cost;
    memcpy(head_cp, head, sizeof(int) * node_num);
    memcpy(edge_des_cp, edge_des, sizeof(int) * tol);
    memcpy(edge_next_cp, edge_next, sizeof(int) * tol);
    memcpy(edge_ori_cap_cp, edge_ori_cap, sizeof(int) * tol);
    memcpy(edge_cap_cp, edge_cap, sizeof(int) * tol);
    memcpy(edge_flow_cp, edge_flow, sizeof(int) * tol);
    memcpy(edge_ori_cost_cp, edge_ori_cost, sizeof(int) * tol);
}

void ZkwMcf::remove_spfa()
{
    for (int i = 0; i < this->node_num + 2; ++i)    dis[i] = INF;

    dis[remove_source] = 0;
    priority_queue<pair<int, int> > q;
    q.push(make_pair(0, remove_source));

    while (!q.empty())
    {
        int u = q.top().second, d = - q.top().first;
        //cout<<u<<endl;
        q.pop();
        if(dis[u] != d) continue;
        for (int i = head[u]; i != -1; i = edge_next[i])
        {
            int v = edge_des[i];
            if (edge_cap[i] && dis[v] > dis[u] + edge_ori_cost[i])
            {
                dis[v] = dis[u] + edge_ori_cost[i];
                q.push(make_pair(-dis[v], v));
            }
        }
    }

    for(int i = 0; i < node_num + 2; i++)
    {
        dis[i] = dis[remove_sink] - dis[i];
    }
}

int ZkwMcf::remove_zkw_aug(int src, int flow)
{
    if(src == this->remove_sink)
    {
        this->min_cost += dis[remove_source] * flow;
        this->max_flow += flow;
        return flow;
    }
    vis[src] = 1;
    int tmp = flow, des;
    for(int i = head[src]; i != -1; i = edge_next[i])
    {
        int des = edge_des[i];
        if(edge_cap[i] && dis[src] == dis[des] + edge_ori_cost[i]  && !vis[des])
        {
            int delta = remove_zkw_aug(edge_des[i], tmp < edge_cap[i] ? tmp : edge_cap[i]);
			edge_cap[i] -= delta;
            edge_flow[i] += delta;
            edge_cap[i^1] += delta;
            edge_flow[i^1] -= delta;
            tmp -= delta;
            if(!tmp) return flow;
        }
    }

    return flow - tmp;
}

bool ZkwMcf::remove_zkw_modlabel()
{
    int delta = INF, des;
    for(int u = 0; u < this->node_num + 2; u++)
    {
        if(!vis[u]) continue;
        for(int i = head[u]; i != -1; i = edge_next[i])
        {
            des = edge_des[i];
            if(edge_cap[i] && !vis[des])    delta = MIN(delta, dis[des] + edge_ori_cost[i] - dis[u]);
        }
    }

    if(delta == INF) return false;
    //cout<<delta<<endl;
    for(int u = 0; u < this->node_num + 2; u++)
    {
        if(!vis[u]) continue;
        dis[u] += delta;
    }
    return true;
}

bool ZkwMcf::remove_run_zkw_mcf(int which)
{
    if(which == 0)
    {
        remove_source = source;
        remove_sink = sink;
        this->min_cost = 0;
        this->max_flow = 0;
    }
    else
    {
        min_cost = min_cost_cp;
        max_flow = 0;
    }
    //this->min_delta_cost = 0;
    //delta_costs[delta_cnt++] = min_delta_cost;
    //remove_spfa();
    if(which == 0)  for(int i = 0; i < node_num; i++)   dis[i] = 0;
    else remove_spfa();
    //for(int i = 0; i < node_num + 2; i++)
        //cout<<dis[i]<<endl;
    do
    {
        do
        {
            memset(vis, 0, sizeof(vis));
        } while(remove_zkw_aug(this->remove_source, INF));
    } while(remove_zkw_modlabel());

    return this->max_flow == this->sum_demand;
}

#endif // __ZKW_MCF_H__
