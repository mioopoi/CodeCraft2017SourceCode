#!/bin/bash

#mycase="topo.txt"
#result="topo_result.txt"

mycase="case1.txt"
result="result1.txt"

rm cdn.tar.gz

./build.sh

cd ./bin


./cdn ../../case_example/2/$mycase ../../case_result/2/$result