#ifndef __OPT_SEARCH_HELPER_H__
#define __OPT_SEARCH_HELPER_H__

/*struct Customer
{
public:
    int node_id;
    int demand;
    int node_cost;

    Customer(node_id = -1, demand = 0, node_cost = 0) : node_id(node_id), demand(demand), node_cost(node_cost) {}
    void* operator new(size_t, void* p)    {return p;}

};

struct customer_demand_cmp_greater
{
    bool operator()(Customer* lhs, Customer* rhs)
    {
        if(lhs->demand != rhs->demand)
            return lhs->demand > rhs->demand;
        return lhs->node_cost > rhs->node_cost;
    }
};*/

struct Candidate
{
    int node_id;
    bool is_customer;
    int demand;
    int node_cost;
    bool is_server;
    int server_level;

    Candidate(int node_id = -1, bool is_customer = 0, int demand = -1, int node_cost = 100000, bool is_server = false, int  server_level = -1) : node_id(node_id),
            is_customer(is_customer), demand(demand), node_cost(node_cost), is_server(is_server), server_level(server_level) {}
    void* operator new(size_t, void* p)    {return p;}
};

struct candidate_demand_cmp_greater
{
    bool operator()(Candidate* lhs, Candidate* rhs)
    {
        if(lhs->demand != rhs->demand)
            return lhs->demand > rhs->demand;
        return lhs->node_cost > rhs->node_cost;
    }
};

#endif
