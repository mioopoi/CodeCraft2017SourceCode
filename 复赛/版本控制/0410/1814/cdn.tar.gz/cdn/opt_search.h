#ifndef __OPT_SEARCH_H__
#define __OPT_SEARCH_H__

#include <iostream>
#include <vector>
#include <algorithm>

#include "opt_search_helper.h"
#include "graph.h"
#include "zkw_mcf.h"

using namespace std;

class OptSearch
{
public:
    Graph* graph;
    ZkwMcf* zkw_mcf;
    int node_num;
    int level_num;

    vector<Candidate*> candidates;

    Candidate* candidate_start_ptr;

    OptSearch(Graph* graph);
    void init_candidates();
    bool run_server_level_mcf();
    bool run_max_level_mcf();
    void construct_candidates_by_demand();
    void construct_first_solution_by_node_demand();
    void construct_first_solution_by_node_demand_with_max_level();
    void deal_with_topo_lv0_zero();
    void deal_with_topo_lv0_one();
    bool decrease_server_with_max_level();
    void update_global_min_cost();

    int global_min_cost;
    int global_flow_cost;
    int* servers;
    int* pre_servers;

};

OptSearch::OptSearch(Graph* graph)
{
    this->graph = graph;
    zkw_mcf = new ZkwMcf(graph);
    node_num = graph->node_num;
    level_num = graph->level_num;

    servers = new int[node_num];
    pre_servers = new int[node_num];
    for(int i = 0; i < node_num; i++)
        servers[i] = pre_servers[i] = -1;

    global_min_cost = 0;
    init_candidates();

}

void OptSearch::init_candidates()
{
    int candidate_ptr_cnt = 0;
    candidate_start_ptr = new Candidate[node_num];
    candidates = vector<Candidate*>(node_num, NULL);

    bool is_customer;
    int demand;
    for(int i = 0; i < node_num; i++)
    {
        //cout<<g_node_customer[i]<<endl;
        //int node_id = -1, bool is_customer = 0, int demand = -1, int node_cost = 100000, bool is_server = false, int  server_level = -
        if(g_node_customer[i] != -1)
        {
            is_customer = true;
            demand = g_customer_need[g_node_customer[i]];
        }
        else
        {
            is_customer = false;
            demand = 0;
        }
        candidates[i] = new (candidate_start_ptr + candidate_ptr_cnt) Candidate(i, is_customer, demand, g_node_cost[i], false, -1);
        candidate_ptr_cnt++;
    }
}

void OptSearch::construct_candidates_by_demand()
{
    sort(candidates.begin(), candidates.end(), candidate_demand_cmp_greater());
    /*for(int i = 0; i < node_num; i++)
    {
        cout<<candidates[i]->node_id<<" "<<candidates[i]->demand<<endl;
    }*/
}

void OptSearch::construct_first_solution_by_node_demand()
{
    construct_candidates_by_demand();
    bool is_satisfied, is_all_satisfied = true;
    int j, demand, node_id;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        demand = candidates[i]->demand;
        if(demand == 0) break;
        is_satisfied = false;
        for(j = 0; j < graph->level_num; j++)
        {
            if(g_server_level[j].power >= demand)
            {
                is_satisfied = true;
                break;
            }
        }

        if(is_satisfied)
        {
            servers[node_id] = j;
            global_min_cost += (g_server_level[j].cost + g_node_cost[node_id]);
        }
        else
        {
            is_all_satisfied = false;
            cout<<"node: "<<node_id<<"is not satisfied"<<endl;
            servers[node_id] = j - 1;
        }
    }

    if(is_all_satisfied)
    {
        cout<<"global_min_cost after construct first demand: "<<global_min_cost<<endl;
        return;
    }
}

void OptSearch::construct_first_solution_by_node_demand_with_max_level()
{
    construct_candidates_by_demand();
    bool is_satisfied, is_all_satisfied = true;
    int j, demand, node_id;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        demand = candidates[i]->demand;
        if(demand == 0) break;
        is_satisfied = false;
        if(g_server_level[level_num - 1].power >= demand)
            is_satisfied = true;
        if(is_satisfied)
        {
            servers[node_id] = level_num - 1;
            global_min_cost += (g_server_level[level_num - 1].cost + g_node_cost[node_id]);
        }
        else
        {
            is_all_satisfied = false;
            cout<<"node: "<<node_id<<"is not satisfied"<<endl;
            servers[node_id] = level_num - 1;
        }
    }

    if(is_all_satisfied)
    {
        cout<<"global_min_cost after construct first demand: "<<global_min_cost<<endl;
        return;
    }
}

void OptSearch::deal_with_topo_lv0_zero()
{
    construct_first_solution_by_node_demand();
    cout<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;

}

void OptSearch::deal_with_topo_lv0_one()
{
    construct_first_solution_by_node_demand();
    reverse(candidates.begin(), candidates.end());
    decrease_server_with_max_level();

    run_server_level_mcf();
    cout<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;
}

bool OptSearch::run_server_level_mcf()
{
    zkw_mcf->init(servers);
    bool is_feasible = zkw_mcf->run_zkw_mcf();
    global_flow_cost = zkw_mcf->min_cost;
    return is_feasible;
}

bool OptSearch::run_max_level_mcf()
{
    zkw_mcf->init(servers, 1);
    bool is_feasible = zkw_mcf->run_zkw_mcf();
    global_flow_cost = zkw_mcf->min_cost;
    if(is_feasible) update_global_min_cost();
    return is_feasible;
}

void OptSearch::update_global_min_cost()
{
    memset(servers, -1, sizeof(int) * node_num);
    global_min_cost = zkw_mcf->cal_server_level(servers);
    //cout<<global_min_cost<<endl;
}

bool OptSearch::decrease_server_with_max_level()
{
    int best_cost = global_min_cost, begin_cost = global_min_cost;
    int node_id, *tmp;
    bool is_feasible;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        if(servers[node_id] == -1) continue;
        memcpy(pre_servers, servers, sizeof(int) * node_num);
        servers[node_id] = -1;
        is_feasible = run_max_level_mcf();
        //cout<<node_id<<" "<<is_feasible<<" "<<global_min_cost<<endl;
        if(is_feasible && global_min_cost < best_cost)
        {
            best_cost = global_min_cost;
        }
        else
        {
            tmp = servers;
            servers = pre_servers;
            pre_servers = tmp;
            global_min_cost = best_cost;
        }

        //cout<<i<<" "<<servers[i]<<endl;
    }
    cout<<"min cost after decrease_server_with_max_level: "<<global_min_cost<<endl;
    if(global_min_cost < begin_cost) return true;
    return false;
}

#endif
