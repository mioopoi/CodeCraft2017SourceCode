#ifndef __ZKW_MCF_H__
#define __ZKW_MCF_H__

#include <iostream>
#include <cstdio>
#include <cstring>
#include <queue>
#include <stack>

#include "graph.h"

using namespace std;

const int MAX_MCF_EDGE = MAX_EDGE_NUMBER * 2;

int head[MAX_NODE_NUMBER];
int pre[MAX_NODE_NUMBER];
int dis[MAX_NODE_NUMBER];
bool vis[MAX_NODE_NUMBER];

int edge_des[MAX_MCF_EDGE];
int edge_next[MAX_MCF_EDGE];
int edge_ori_cap[MAX_MCF_EDGE];
int edge_cap[MAX_MCF_EDGE];
int edge_cost[MAX_MCF_EDGE];
int edge_flow[MAX_MCF_EDGE];
int edge_ori_cost[MAX_MCF_EDGE];

class ZkwMcf
{
public:
    int source;    // 超源点
    int sink;      // 超汇点
    int tol;       // 计数变量
    int node_num;         // 节点总数量（包括超源点和超汇点）
    int edge_num;         // 有向边总数量（不包括虚拟边）
    int max_edge_num;

    int min_cost;  // 最小费用
    int max_flow;  // 最大流
    int sum_demand;

    Graph* graph;  // 原图

    ZkwMcf(Graph *graph);

    void add_edge(int src, int des, int cap, int cost);
    void init(vector<int>& servers);
    ~ZkwMcf();

    /* zkw */
    int min_delta_cost;
    int zkw_aug(int src, int flow);
    bool run_zkw_mcf();
    bool zkw_modlabel();
    /* */

    void construct_solution(vector<vector<int>>& paths, vector<int>& servers);

};

ZkwMcf::ZkwMcf(Graph* graph)
{
    //cout << "Hello MinCostFlow!"<< endl;
    this->graph = graph;
    this->source = graph->node_num;   // 添加超源点
    this->sink = graph->node_num + 1; // 添加超汇点
    this->tol = 0;
    this->node_num = graph->node_num + 2;
    this->min_cost = INF;
    this->max_flow = 0;
    this->sum_demand = 0;

    memset(head, -1, sizeof(head));

    for (int i = 0; i < graph->edge_num * 2; i++)
    {
        this->add_edge(g_edge_src[i], g_edge_des[i], g_edge_cap[i], g_edge_cost[i]);
    }
    // 添加有向边：所有demand节点->超汇点
    for(int i = 0; i < graph->node_num; i++)
    {
        if(g_node_customer[i] == -1) continue;
        this->add_edge(i, sink, g_customer_need[g_node_customer[i]], 0);
        this->sum_demand += g_customer_need[g_node_customer[i]];
        //cout<<i<<" "<<g_customer_need[g_node_customer[i]]<<endl;
    }
    //cout << "total edges: " << tol << endl;
}

void ZkwMcf::add_edge(int src, int des, int cap, int cost)
{

	edge_des[tol] = des;
	edge_next[tol] = head[src];
	edge_ori_cap[tol] = cap;
	edge_cap[tol] = cap;
	edge_cost[tol] = cost;
	edge_ori_cost[tol] = cost;
	edge_flow[tol] = 0;
    head[src] = tol++;

	edge_des[tol] = src;
	edge_next[tol] = head[des];
	edge_ori_cap[tol] = 0;
	edge_cap[tol] = 0;
	edge_cost[tol] = -cost;
	edge_ori_cost[tol] = -cost;
	edge_flow[tol] = 0;
    head[des] = tol++;

}

void ZkwMcf::init(vector<int>& servers)
{
        // 参数重置
    this->min_cost = INF;
    this->max_flow = 0;
    for (int i = 0; i < this->tol; ++i)
    {
        edge_cap[i] = edge_ori_cap[i];
        edge_cost[i] = edge_ori_cost[i];
        edge_flow[i] = 0;
    }
    this->tol = (this->graph->edge_num * 2 + this->graph->customer_num) * 2;

    for (int edge_id = head[source]; edge_id != -1; edge_id = edge_next[edge_id])
    {
        int des = edge_des[edge_id];
        if (head[des] != -1)
        {
			head[des] = edge_next[head[des]];
        }
    }
    head[source] = -1;


    int cnt = 0;
    // 添加有向边：超源点->所有supply节点
    for (int i = 0; i < servers.size(); ++i)
    {
        if (servers[i] != -1)  // 节点i是supply节点
        {
            this->add_edge(this->source, i, g_server_level[servers[i]].power, 0);
            //cnt += g_server_level[i].power;
        }
    }
}

int ZkwMcf::zkw_aug(int src, int flow)
{
    if(src == this->sink)
    {
        this->min_cost += this->min_delta_cost * flow;
        this->max_flow += flow;
        return flow;
    }
    vis[src] = 1;
    int tmp = flow;
    for(int i = head[src]; i != -1; i = edge_next[i])
        if(edge_cap[i] && !edge_cost[i] && !vis[edge_des[i]])
        {
            int delta = zkw_aug(edge_des[i], tmp < edge_cap[i] ? tmp : edge_cap[i]);
			edge_cap[i] -= delta;
            edge_flow[i] += delta;
            edge_cap[i^1] += delta;
            edge_flow[i^1] -= delta;
            tmp -= delta;
            if(!tmp) return flow;
        }
    return flow - tmp;
}

bool ZkwMcf::zkw_modlabel()
{
    int delta = INF;
    for(int u = 0; u < this->node_num; u++)
    {
        if(!vis[u]) continue;
        for(int i = head[u]; i != -1; i = edge_next[i])
            if(edge_cap[i] && !vis[edge_des[i]] && edge_cost[i] < delta)
                delta = edge_cost[i];
    }

    if(delta == INF) return false;
    for(int u = 0; u < this->node_num; u++)
    {
        if(!vis[u]) continue;
        for(int i = head[u]; i != -1; i = edge_next[i])
            edge_cost[i] -= delta, edge_cost[i^1] += delta;
    }
    this->min_delta_cost += delta;
    return true;
}

bool ZkwMcf::run_zkw_mcf()
{
    this->min_cost = 0;
    this->max_flow = 0;
    this->min_delta_cost = 0;
    //delta_costs[delta_cnt++] = min_delta_cost;

    do
    {
        do
        {
            memset(vis, 0, sizeof(vis));
        } while(zkw_aug(this->source, INF));
    } while(zkw_modlabel());

    return this->max_flow == this->sum_demand;
}

ZkwMcf::~ZkwMcf()
{
    /*for(int i = 0; i < this->node_num; i++)
    {
        delete this->cost_matrix[i];
    }*/
}

void ZkwMcf::construct_solution(vector<vector<int>>& paths, vector<int>& servers)
{
    vector<int> edge_path(node_num + 2, -1);
    int flow_cnt = 0;
    while(true)
    {
        int flow = INF, cur = source, des, cnt = 0;
        while(cur != sink)
        {
            for(int i = head[cur]; i != -1; i = edge_next[i])
            {
                if(edge_flow[i] <= 0) continue;
                if(edge_flow[i] < flow) flow = edge_flow[i];
                edge_path[cnt++] = i;
                cur = edge_des[i];
                break;
            }
            if(cur == source) break;
        }
        if(flow == INF) break;
        vector<int> path(cnt + 2, 0);
        for(int i = 0; i < cnt; i++)
        {
            flow_cnt += flow;
            edge_flow[edge_path[i]] -= flow;
            path[i] = edge_des[edge_path[i]];
        }
        int server_id = path[0];
        path[cnt + 1] = servers[server_id];
        path[cnt] = flow;
        path[cnt - 1] = g_node_customer[server_id];
        paths.push_back(path);

    }
}

#endif // __ZKW_MCF_H__
