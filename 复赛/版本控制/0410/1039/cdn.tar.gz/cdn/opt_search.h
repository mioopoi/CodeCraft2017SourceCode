#ifndef __OPT_SEARCH_H__
#define __OPT_SEARCH_H__

#include <iostream>
#include <vector>
#include <algorithm>

#include "opt_search_helper.h"
#include "graph.h"
#include "zkw_mcf.h"

using namespace std;

class OptSearch
{
public:
    Graph* graph;
    ZkwMcf* zkw_mcf;
    int node_num;

    vector<Candidate*> candidates;

    Candidate* candidate_start_ptr;

    OptSearch(Graph* graph);
    void init_candidates();
    void construct_candidates_by_demand();
    void construct_first_solution_by_node_demand();
    void deal_with_topo_lv0_zero();

    int global_min_cost;
    vector<int> servers;

};

OptSearch::OptSearch(Graph* graph)
{
    this->graph = graph;
    zkw_mcf = new ZkwMcf(graph);
    node_num = graph->node_num;
    servers = vector<int>(node_num, -1);
    global_min_cost = 0;
    init_candidates();

}

void OptSearch::init_candidates()
{
    int candidate_ptr_cnt = 0;
    candidate_start_ptr = new Candidate[node_num];
    candidates = vector<Candidate*>(node_num, NULL);

    bool is_customer;
    int demand;
    for(int i = 0; i < node_num; i++)
    {
        //cout<<g_node_customer[i]<<endl;
        //int node_id = -1, bool is_customer = 0, int demand = -1, int node_cost = 100000, bool is_server = false, int  server_level = -
        if(g_node_customer[i] != -1)
        {
            is_customer = true;
            demand = g_customer_need[g_node_customer[i]];
        }
        else
        {
            is_customer = false;
            demand = 0;
        }
        candidates[i] = new (candidate_start_ptr + candidate_ptr_cnt) Candidate(i, is_customer, demand, g_node_cost[i], false, -1);
        candidate_ptr_cnt++;
    }
}

void OptSearch::construct_candidates_by_demand()
{
    sort(candidates.begin(), candidates.end(), candidate_demand_cmp_greater());
    /*for(int i = 0; i < node_num; i++)
    {
        cout<<candidates[i]->node_id<<" "<<candidates[i]->demand<<endl;
    }*/
}

void OptSearch::construct_first_solution_by_node_demand()
{
    construct_candidates_by_demand();
    bool is_satisfied, is_all_satisfied = true;
    int j, demand, node_id;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        demand = candidates[i]->demand;
        if(demand == 0) break;
        is_satisfied = false;
        for(j = 0; j < graph->level_num; j++)
        {
            if(g_server_level[j].power >= demand)
            {
                is_satisfied = true;
                break;
            }
        }

        if(is_satisfied)
        {
            servers[node_id] = j;
            global_min_cost += (g_server_level[j].cost + g_node_cost[node_id]);
        }
        else
        {
            is_all_satisfied = false;
            cout<<"node: "<<node_id<<"is not satisfied"<<endl;
            servers[node_id] = j - 1;
        }
    }

    if(is_all_satisfied)
    {
        cout<<"global_min_cost after construct first demand: "<<global_min_cost<<endl;
        return;
    }
}

void OptSearch::deal_with_topo_lv0_zero()
{
    construct_first_solution_by_node_demand();
    this->zkw_mcf->init(servers);
    this->zkw_mcf->run_zkw_mcf();
    cout<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;

}

#endif
