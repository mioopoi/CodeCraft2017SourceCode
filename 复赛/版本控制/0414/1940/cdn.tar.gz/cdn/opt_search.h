#ifndef __OPT_SEARCH_H__
#define __OPT_SEARCH_H__

#include <iostream>
#include <vector>
#include <algorithm>

#include "opt_search_helper.h"
#include "graph.h"
#include "zkw_mcf.h"

using namespace std;

class OptSearch
{
public:
    Graph* graph;
    ZkwMcf* zkw_mcf;
    int node_num;
    int customer_num;
    int level_num;

    vector<Candidate*> candidates;
    vector<Candidate*> candidates_cp;
    vector<Candidate*> increase_candidates;
    vector<Candidate*> increase_candidates_cp;

    Candidate* candidate_start_ptr;

    OptSearch(Graph* graph);

    /*初始解构造方法*/
    int choose_server_by_node_demand(double percent);
    int choose_server_by_node_max_flow(bool re_cal, double percent);
    void choose_server_by_pass_flow(bool re_cal, double percent);
    void choose_server_by_ave_cost(bool re_cal, double percent);
    void construct_first_solution_combine_demand_and_flow();
    void construct_first_solution_by_max_flow();
    void construct_first_solution_by_ave_cost();
    void construct_first_solution_by_combine_ave_cost_and_flow();
    void construct_first_solution_by_combine_ave_cost_and_demand();
    /**/

    /*candidates构造相关*/
    void init_candidates();
    void calculate_candidates_neighbor();
    void calculate_candidates_overflow_cost();
    bool calculate_candidates_pass_cost();
    void calculate_candidates_ave_cost();
    /**/

    /*费用流相关*/
    bool run_server_level_mcf();
    bool run_max_level_mcf();
    void set_mcf_state(int which = 0);
    void update_global_min_cost();
    bool zkw_exchange_server(int in_id, int in_lv, int out_id);
    /*费用流相关*/

    /*topo策略相关*/
    void topo_strategy();
    void deal_with_topo_lv2_zero();
    void deal_with_topo_lv0_zero();
    void deal_with_topo_lv0_one();
    void lv0_loop();
    void lv0_add_server(int type);
    /**/

    bool decrease_server_with_max_level();
    bool increase_server_with_max_level();
    bool increase_server_with_server_level();
    bool decrease_server_with_server_level();
    bool down_server_level();
    bool add_server_down_level();

    /*交换策略相关*/
    bool exchange_server_by_node_pass_cost();
    bool exchange_one_node_with_all_server(int in_id);
    int exchange_node(int in_id, int in_lv, int out_id, int& real_lv);
    bool exchange_one_server_with_other_candidates(int out_id);
    bool exchange_server_by_node_pass_cost_lv2();
    bool exchange_server_with_neighbor();
    bool lv0_jump_from_local();

    /**/
    bool show_detail_info();
    /**/
    int global_min_cost;
    int global_flow_cost;
    int* servers;
    int* pre_servers;
    Candidate* empty_candidate;
    int topo_lv;

public:
    bool decrease_level_one_server(int server_id, int target_level);
    bool increase_level_one_server(int server_id, int target_level);
    bool remove_a_server(int server_id);

};

OptSearch::OptSearch(Graph* graph)
{
    this->graph = graph;
    zkw_mcf = new ZkwMcf(graph);
    node_num = graph->node_num;
    customer_num =graph->customer_num;
    level_num = graph->level_num;

    servers = new int[node_num];
    pre_servers = new int[node_num];

    memset(servers, -1, sizeof(int) * node_num);

    global_min_cost = 0;
    init_candidates();

    if(node_num < 200) topo_lv = 0;
    else if(node_num < 500) topo_lv = 1;
    else topo_lv = 2;

}

void OptSearch::init_candidates()
{
    int candidate_ptr_cnt = 0;
    candidate_start_ptr = new Candidate[node_num + 2];

    empty_candidate = new (candidate_start_ptr + candidate_ptr_cnt) Candidate();
    candidate_ptr_cnt++;
    increase_candidates = vector<Candidate*>(node_num, empty_candidate);
    increase_candidates_cp = vector<Candidate*>(node_num, empty_candidate);

    candidates = vector<Candidate*>(node_num, NULL);
    candidates_cp = vector<Candidate*>(node_num, NULL);

    bool is_customer;
    int demand;
    for(int i = 0; i < node_num; i++)
    {
        //cout<<g_node_customer[i]<<endl;
        //int node_id = -1, bool is_customer = 0, int demand = -1, int node_cost = 100000, bool is_server = false, int  server_level = -
        if(g_node_customer[i] != -1)
        {
            is_customer = true;
            demand = g_customer_need[g_node_customer[i]];
        }
        else
        {
            is_customer = false;
            demand = 0;
        }
        candidates[i] = new (candidate_start_ptr + candidate_ptr_cnt) Candidate(i, is_customer, demand, g_node_cost[i], false, -1);
        candidates_cp[i] = candidates[i];
        candidate_ptr_cnt++;
    }
}

void OptSearch::calculate_candidates_neighbor()
{
    int max_flow, cus_num, des;
    for(int i = 0; i < node_num; i++)
    {
        max_flow = 0, cus_num = 0;
        if(g_node_customer[i] != -1)
            cus_num++;
        for(int j = g_node_head[i]; j != -1; j = g_edge_next[j])
        {
            max_flow += g_edge_cap[j];
            des = g_edge_des[j];
            if(g_node_customer[des] != -1)
                cus_num++;
        }
        candidates_cp[i]->max_flow = max_flow;
        candidates_cp[i]->cus_num = cus_num;
        //cout<<i<<" "<<max_flow<<" "<<cus_num<<endl;
    }
}

void OptSearch::calculate_candidates_overflow_cost()
{
    zkw_mcf->calculate_overflow_cost(candidates_cp);
}

bool OptSearch::calculate_candidates_pass_cost()
{
    zkw_mcf->init(servers, 0);
    bool is_feasible = zkw_mcf->run_zkw_mcf_record_all_cost();
    for(int i = 0; i < node_num; i++)
    {
        candidates_cp[i]->pass_cost = mcf_cost_array[i];
        //cout<<i<<" "<<mcf_cost_array[i]<<endl;
    }
    //cout<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;
    return is_feasible;
}

void OptSearch::calculate_candidates_ave_cost()
{
    memcpy(pre_servers, servers, sizeof(int) * node_num);

    memset(servers, -1, sizeof(int) * node_num);
    for(int i = 0; i < node_num; i++)
    {
        servers[i] = level_num - 1;
        run_server_level_mcf();
        candidates_cp[i]->ave_cost = (zkw_mcf->min_cost + g_node_cost[i]) / (zkw_mcf->max_flow + 0.1);
        servers[i] = -1;
    }
    memcpy(servers, pre_servers, sizeof(int) * node_num);
}

int OptSearch::choose_server_by_node_max_flow(bool re_cal, double percent)
{
    if(re_cal)  calculate_candidates_neighbor();
    sort(candidates.begin(), candidates.end(), candidate_flow_cmp_greater());

    int middle_num = int(node_num * percent);
    int node_id;
    for(int i = 0; i < middle_num; i++)
    {
        node_id = candidates[i]->node_id;
        increase_candidates_cp[node_id] = candidates[i];
        servers[node_id] = level_num - 1;
    }
    return middle_num;
}

int OptSearch::choose_server_by_node_demand(double percent)
{
    sort(candidates.begin(), candidates.end(), candidate_demand_cmp_greater());

    int cus_num = int(customer_num * percent);
    int cus_cnt = 0, node_id;
    for(int i = 0; i < cus_num; i++)
    {
        node_id = candidates[i]->node_id;
        increase_candidates_cp[node_id] = candidates[i];
        servers[node_id] = level_num - 1;
    }

    //sort(increase_candidates.begin(), increase_candidates.end(), candidate_demand_cmp_greater());
    //for(int i = 0; i < node_num; i++)
    //cout<<increase_candidates[i]->node_id<<endl;
    return cus_num;
}

void OptSearch::choose_server_by_ave_cost(bool re_cal, double percent)
{
    if(re_cal)
    {
        calculate_candidates_ave_cost();
    }
    sort(candidates.begin(), candidates.end(), candidate_ave_cost_cmp_less());
    int middle_num = int(node_num * percent);
    int node_id;
    for(int i = 0; i < middle_num; i++)
    {
        node_id = candidates[i]->node_id;
        increase_candidates_cp[node_id] = candidates[i];
        servers[node_id] = level_num - 1;
    }
}

void OptSearch::choose_server_by_pass_flow(bool re_cal, double percent)
{
    if(re_cal) calculate_candidates_pass_cost();
    sort(candidates.begin(), candidates.end(), candidate_pass_cost_cmp_greater());
    int num = node_num * percent, node_id = 0;
    for(int i = 0; i < num; i++)
    {
        node_id = candidates[i]->node_id;
        servers[node_id] = level_num - 1;
        increase_candidates_cp[node_id] = candidates[i];
    }
    increase_candidates = increase_candidates_cp;
    sort(increase_candidates.begin(), increase_candidates.end(), candidate_pass_cost_cmp_greater());
}

void OptSearch::construct_first_solution_by_max_flow()
{
    double p0 = 0.2;
    choose_server_by_node_max_flow(true, p0);
    bool is_feasible = run_max_level_mcf();
    while(!is_feasible)
    {
        p0 += 0.1;
        cout<<p0<<endl;
        choose_server_by_node_max_flow(false, p0);
        is_feasible = run_max_level_mcf();
    }
    increase_candidates = increase_candidates_cp;
    sort(increase_candidates.begin(), increase_candidates.end(), candidate_flow_cmp_greater());
}

void OptSearch::construct_first_solution_combine_demand_and_flow()
{
    double p0 = 0.1, p1 = 0.1;
    choose_server_by_node_demand(p0);
    choose_server_by_node_max_flow(true, p1);
    bool is_feasible = run_max_level_mcf();
    while(!is_feasible)
    {
        p0 += 0.1;
        p1 += 0.1;
        cout<<p0<<" "<<p1<<endl;
        choose_server_by_node_demand(p0);
        choose_server_by_node_max_flow(false, p1);
        is_feasible = run_max_level_mcf();
    }
    increase_candidates = increase_candidates_cp;
    sort(increase_candidates.begin(), increase_candidates.end(), candidate_flow_cmp_greater());
}

void OptSearch::construct_first_solution_by_ave_cost()
{
    double p0 = 0.2;
    choose_server_by_ave_cost(true, p0);
    bool is_feasible = run_max_level_mcf();
    while(!is_feasible)
    {
        p0 += 0.1;
        cout<<p0<<endl;
        choose_server_by_node_max_flow(false, p0);
        is_feasible = run_max_level_mcf();
    }
    increase_candidates = increase_candidates_cp;
    sort(increase_candidates.begin(), increase_candidates.end(), candidate_flow_cmp_greater());
}

void OptSearch::construct_first_solution_by_combine_ave_cost_and_flow()
{
    double p0 = 0.1, p1 = 0.1;
    choose_server_by_node_max_flow(true, p1);
    choose_server_by_ave_cost(true, p0);
    bool is_feasible = run_max_level_mcf();
    while(!is_feasible)
    {
        p0 += 0.1;
        p1 += 0.1;
        cout<<p0<<" "<<p1<<endl;
        choose_server_by_node_max_flow(false, p1);
        choose_server_by_ave_cost(false, p0);
        is_feasible = run_max_level_mcf();
    }
    increase_candidates = increase_candidates_cp;
    sort(increase_candidates.begin(), increase_candidates.end(), candidate_flow_cmp_greater());
}

void OptSearch::construct_first_solution_by_combine_ave_cost_and_demand()
{
    double p0 = 0.1, p1 = 0.1;
    choose_server_by_node_demand(p1);
    choose_server_by_ave_cost(true, p0);

    bool is_feasible = run_max_level_mcf();
    while(!is_feasible)
    {
        p0 += 0.1;
        p1 += 0.1;
        cout<<p0<<" "<<p1<<endl;
        choose_server_by_node_demand(p1);
        choose_server_by_ave_cost(false, p0);
        is_feasible = run_max_level_mcf();
    }
    increase_candidates = increase_candidates_cp;
    sort(increase_candidates.begin(), increase_candidates.end(), candidate_flow_cmp_greater());
}

void OptSearch::deal_with_topo_lv0_zero()
{
    //construct_first_solution_combine_demand_and_flow();
    //calculate_candidates_ave_cost();
    //sort(candidates.begin(), candidates.end(), candidate_ave_cost_cmp_min());
    //construct_first_solution_by_demand();
    //construct_first_solution_by_max_flow();
    //construct_first_solution_by_ave_cost();
    construct_first_solution_by_combine_ave_cost_and_flow();
    sort(candidates.begin(), candidates.end(), candidate_cus_num_cmp_greater());
    //construct_first_solution_by_combine_ave_cost_and_demand();
    //calculate_candidates_neighbor();
    //sort(candidates.begin(), candidates.end(), candidate_flow_cmp_greater());
    reverse(candidates.begin(), candidates.end());

    decrease_server_with_max_level();
    increase_server_with_max_level();
    decrease_server_with_max_level();
    down_server_level();

    int best_cost;
    while(true)
    {
        best_cost = global_min_cost;
        exchange_server_by_node_pass_cost_lv2();
        increase_server_with_server_level();
        decrease_server_with_server_level();
        down_server_level();
        if(best_cost == global_min_cost) break;
    }

    /*while(true)
    {
        best_cost = global_min_cost;
        exchange_server_by_node_pass_cost_lv2();
        increase_server_with_server_level();
        decrease_server_with_server_level();
        down_server_level();
        if(best_cost == global_min_cost) break;
    }*/
    /*servers[3] = 5;
    servers[7] = 3;
    servers[14] = 4;
    servers[36] = 3;
    servers[69] = 4;
    servers[103] = 3;
    servers[125] = 3;
    servers[129] = 3;
    servers[155] = 5;
    run_max_level_mcf();*/

    //servers[69] = 4;
    //servers[38] = -1;
    //servers[103] = 4;
    //servers[130] = -1;
    //servers[7] = 5;
    //servers[36] = 3;
    //servers[120] = -1;
    /*down_server_level();
    bool is_feasible = run_server_level_mcf();
    cout<<is_feasible<<" "<<global_min_cost<<endl;*/

    //calculate_candidates_pass_cost();
    /*for(int i = 0; i < node_num; i++)
    {
        if(servers[i] == -1) continue;
        cout<<i<<": ";
        for(int j = g_node_head[i]; j != -1; j = g_edge_next[j])
            cout<<g_edge_des[j]<<" ";
        cout<<endl;
    }*/
    //cout<<global_min_cost<<endl;
    //for(int i = 0; i < node_num; i++)
        //cout<<increase_candidates[i]->node_id<<endl;
    //reverse(candidates.begin(), candidates.end());
    //decrease_server_with_max_level();

}

void OptSearch::deal_with_topo_lv0_one()
{
    int* best_servers = new int[node_num];
    int best_min_cost;

    construct_first_solution_combine_demand_and_flow();
    //construct_first_solution_by_combine_ave_cost_and_flow();
    //construct_first_solution_by_max_flow();
    reverse(candidates.begin(), candidates.end());

    decrease_server_with_max_level();
    increase_server_with_max_level();
    decrease_server_with_max_level();
    down_server_level();

    lv0_loop();

    memcpy(best_servers, servers, sizeof(int) * node_num);
    best_min_cost = global_min_cost;
    lv0_add_server(0);

    lv0_loop();

    if(best_min_cost < global_min_cost)
    {
        memcpy(servers, best_servers, sizeof(int) * node_num);
        global_min_cost = best_min_cost;
    }
    delete best_servers;
}

void OptSearch::lv0_loop()
{
    int best_cost, fail_neighbor = INF, fail_node_pass = INF;
    while(true)
    {

        if(fail_neighbor == global_min_cost) break;
        if(!exchange_server_with_neighbor())
        {
            fail_neighbor = global_min_cost;
        }

        decrease_server_with_server_level();
        down_server_level();

        if(fail_node_pass == global_min_cost) break;
        if(!exchange_server_by_node_pass_cost_lv2())
        {
            fail_node_pass = global_min_cost;
        }

        down_server_level();
        decrease_server_with_server_level();
    }
}

void OptSearch::lv0_add_server(int type)
{
    if(type == 0)
    {
        choose_server_by_pass_flow(true, 0.1);
    }
    else if(type == 1)
    {
        choose_server_by_ave_cost(true, 0.1);
    }
    else
    {
        choose_server_by_node_max_flow(false, 0.05);
        sort(candidates.begin(), candidates.end(), candidate_flow_cmp_greater());
    }
    global_min_cost = INF;
    decrease_server_with_max_level();
}

bool OptSearch::lv0_jump_from_local()
{
    int increase = 2000;
    int* best_servers = new int[node_num];
    int best_min_cost;
    memcpy(best_servers, servers, sizeof(int) * node_num);
    best_min_cost = global_min_cost;

    sort(candidates.begin(), candidates.end(), candidate_flow_cmp_greater());
    int node_id;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        if(servers[node_id] == -1) continue;

        g_node_cost[node_id] += increase;
        global_min_cost += increase;
        lv0_loop();
        g_node_cost[node_id] -= increase;
        if(global_min_cost < best_min_cost)
        {
            memcpy(best_servers, servers, sizeof(int) * node_num);
            best_min_cost = global_min_cost;
        }
        else
        {
            memcpy(servers, best_servers, sizeof(int) * node_num);
            global_min_cost = best_min_cost;
        }

    }


}

void OptSearch::deal_with_topo_lv2_zero()
{
    construct_first_solution_combine_demand_and_flow();
    //construct_first_solution_by_max_flow();
    reverse(candidates.begin(), candidates.end());


    decrease_server_with_max_level();
    increase_server_with_max_level();
    decrease_server_with_max_level();
    down_server_level();

    exchange_server_by_node_pass_cost_lv2();
    down_server_level();
    exchange_server_with_neighbor();
    down_server_level();

    exchange_server_by_node_pass_cost_lv2();
    down_server_level();
    exchange_server_with_neighbor();
    down_server_level();
}

void OptSearch::topo_strategy()
{
    if(topo_lv == 0)
    {
        deal_with_topo_lv0_one();
        //add_server_down_level();
        /*lv0_jump_from_local();
        add_server_down_level();
        lv0_jump_from_local();
        add_server_down_level();*/
    }
    else if(topo_lv == 1)
    {
        deal_with_topo_lv0_one();
        //add_server_down_level();
    }
    else
    {
        deal_with_topo_lv2_zero();
    }


    run_server_level_mcf();
    cout<<global_min_cost<<" "<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;

    //show_detail_info();
}

bool OptSearch::show_detail_info()
{
    memset(servers, -1, sizeof(int) * node_num);
    //(0, 3) (11, 2) (16, 5) (37, 3) (38, 3) (65, 5) (74, 2) (110, 3) (132, 5) (152, 1)

    servers[0] = level_num - 1;
    servers[11] = level_num - 1;
    servers[16] = level_num - 1;
    servers[37] = level_num - 1;
    servers[38] = level_num - 1;
    servers[65] = level_num - 1;
    servers[74] = level_num - 1;
    servers[110] = level_num - 1;
    servers[132] = level_num - 1;
    servers[152] = level_num - 1;
    run_server_level_mcf();
    down_server_level();
    run_server_level_mcf();
    cout<<global_min_cost<<" "<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;

    /*for(int i = 0; i < node_num; i++)
    {
        if(servers[i] != -1)
        {
            cout<<i<<" "<<servers[i]<<endl;
        }
    }*/
    //servers[155] = -1;
    //servers[110] = 5;
    /*servers[16] = 5;
    servers[110] = 3;
    servers[132] = 5;
    servers[134] = -1;*/
    /*run_server_level_mcf();
    cout<<global_min_cost<<" "<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;
    down_server_level();
    run_server_level_mcf();
    cout<<global_min_cost<<" "<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;

    decrease_server_with_server_level();
    run_server_level_mcf();
    cout<<global_min_cost<<" "<<zkw_mcf->max_flow<<" "<<zkw_mcf->sum_demand<<endl;*/
    /*for(int i = 0; i < node_num; i++)
    {
        if(g_node_customer[i] != -1)
            cout<<i<<" ";
    }
    cout<<endl;*/

    /*int node_id;
    sort(candidates.begin(), candidates.end(), candidate_flow_cmp_greater());
    for(int i = 0; i < node_num; i++)
    {
        //if(candidates[i]->node_id == 21)
            //cout<<1111111111111111111111<<endl;
        cout<<i<<" "<<candidates[i]->node_id<<" "<<candidates[i]->max_flow<<endl;
    }*/

    /*calculate_candidates_pass_cost();
    sort(candidates.begin(), candidates.end(), candidate_pass_cost_cmp_greater());
    for(int i = 0; i < node_num; i++)
    {
        cout<<i<<" "<<candidates[i]->node_id<<" "<<candidates[i]->pass_cost<<endl;
    }*/
}

bool OptSearch::add_server_down_level()
{
    int* best_servers = new int[node_num];
    int best_min_cost = global_min_cost;
    memcpy(best_servers, servers, sizeof(int) * node_num);

    int node_id;
    for(int i = 0; i < node_num; i++)
    {
        if(increase_candidates[i] == empty_candidate) continue;
        node_id = increase_candidates[i]->node_id;
        if(servers[node_id] != -1) continue;

        servers[node_id] = level_num - 1;
        run_server_level_mcf();
        down_server_level();
        if(global_min_cost < best_min_cost)
        {
            break;
        }
        else
        {
            memcpy(servers, best_servers, sizeof(int) * node_num);
            global_min_cost = best_min_cost;
        }
    }
    delete best_servers;
    return true;
}

bool OptSearch::run_server_level_mcf()
{
    zkw_mcf->init(servers);
    bool is_feasible = zkw_mcf->run_zkw_mcf();
    if(is_feasible) update_global_min_cost();
    return is_feasible;
}

bool OptSearch::run_max_level_mcf()
{
    zkw_mcf->init(servers, 1);
    bool is_feasible = zkw_mcf->remove_run_zkw_mcf();
    global_flow_cost = zkw_mcf->min_cost;
    if(is_feasible) update_global_min_cost();
    return is_feasible;
}

void OptSearch::update_global_min_cost()
{
    memset(servers, -1, sizeof(int) * node_num);
    global_min_cost = zkw_mcf->cal_server_level(servers);
    //cout<<global_min_cost<<endl;
}

bool OptSearch::decrease_server_with_max_level()
{
    set_mcf_state();

    int best_cost = global_min_cost, begin_cost = global_min_cost;
    int node_id, *tmp, tmp_lv;
    bool is_feasible;

    int tmp_cost;
    int cnt = 0;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        if(servers[node_id] == -1) continue;
        //memcpy(pre_servers, servers, sizeof(int) * node_num);
        tmp_lv = servers[node_id];
        memcpy(pre_servers, servers, sizeof(int) * node_num);

        //servers[node_id] = -1;
        //is_feasible = remove_a_server(node_id);
        cnt++;
        //is_feasible = run_max_level_mcf();
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl;
        is_feasible = decrease_level_one_server(node_id, -1);
        //is_feasible = zkw_mcf->remove_a_server(servers, node_id);
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl;

        if(is_feasible && global_min_cost < best_cost)
        {
            zkw_mcf->set_state_from_cur_state();
            best_cost = global_min_cost;
        }
        else
        {
            memcpy(servers, pre_servers, sizeof(int) * node_num);
            global_min_cost = best_cost;
        }
        //if(node_id == 150) break;
        //break;
        //cout<<i<<" "<<servers[i]<<endl;
    }

    //cout<<"cnts: "<<cnt<<endl;
    cout<<"min cost after decrease_server_with_max_level: "<<global_min_cost<<endl;
    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::decrease_server_with_server_level()
{
    set_mcf_state(1);

    int best_cost = global_min_cost, begin_cost = global_min_cost;
    int node_id, *tmp, tmp_lv;
    bool is_feasible;

    int cnt = 0;
    for(int i = 0; i < node_num; i++)
    {
        node_id = candidates[i]->node_id;
        if(servers[node_id] == -1) continue;
        memcpy(pre_servers, servers, sizeof(int) * node_num);
        //is_feasible = remove_a_server(node_id);
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl;
        //is_feasible = zkw_mcf->remove_a_server(servers, node_id);
        //is_feasible = run_server_level_mcf();
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl;

        //memcpy(servers, pre_servers, sizeof(int) * node_num);
        is_feasible = decrease_level_one_server(node_id, -1);

        cnt++;
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl;
        if(is_feasible && global_min_cost < best_cost)
        {
            zkw_mcf->set_state_from_cur_state();
            best_cost = global_min_cost;
        }
        else
        {
            memcpy(servers, pre_servers, sizeof(int) * node_num);
            global_min_cost = best_cost;
        }
        //if(node_id == 150) break;
        //break;
        //cout<<i<<" "<<servers[i]<<endl;
    }
    //cout<<"cnts: "<<cnt<<endl;
    cout<<"min cost after decrease_server_with_server_level: "<<global_min_cost<<endl;
    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::increase_server_with_max_level()
{
    clock_t start = clock();

    set_mcf_state();

    int best_cost = global_min_cost, begin_cost = global_min_cost;
    int node_id, tmp_lv;
    bool is_feasible;

    int cnt = 0;
    for(int i = 0; i < node_num; i++)
    {
        if(increase_candidates[i]->node_id == -1) break;
        cnt++;
        node_id = increase_candidates[i]->node_id;
        //cout<<node_id<<endl;
        if(servers[node_id] != -1) continue;

        memcpy(pre_servers, servers, sizeof(int) * node_num);
        servers[node_id] = 0;
        //is_feasible = this->run_max_level_mcf();
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl;

        //memcpy(servers, pre_servers, sizeof(int) * node_num);
        is_feasible = increase_level_one_server(node_id, level_num - 1);
        //is_feasible = add_a_server(node_id);
        //is_feasible = run_max_level_mcf();
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl<<endl;
        if(is_feasible && global_min_cost < best_cost)
        {
            zkw_mcf->set_state_from_cur_state();
            best_cost = global_min_cost;
        }
        else
        {
            memcpy(servers, pre_servers, sizeof(int) * node_num);
            global_min_cost = best_cost;
        }
        //if(node_id == 150) break;
        //break;
        //cout<<i<<" "<<servers[i]<<endl;
    }
    cout<<"cnts: "<<cnt<<endl;
    cout<<"min cost after increase_server_with_max_level: "<<global_min_cost<<endl;

    clock_t end = clock();
    printf("Use Time:%f\n",(double(end-start)/CLOCKS_PER_SEC));

    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::increase_server_with_server_level()
{
    clock_t start = clock();

    //set_mcf_state();

    int best_cost = global_min_cost, begin_cost = global_min_cost;
    int node_id, tmp_lv;
    bool is_feasible;

    int cnt = 0;
    for(int i = 0; i < node_num; i++)
    {
        if(increase_candidates[i]->node_id == -1) break;
        cnt++;
        node_id = increase_candidates[i]->node_id;
        //cout<<node_id<<endl;
        if(servers[node_id] != -1) continue;
        memcpy(pre_servers, servers, sizeof(int) * node_num);

        //servers[node_id] = level_num - 1;
        //is_feasible = this->run_max_level_mcf();
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl;
        is_feasible = increase_level_one_server(node_id, level_num - 1);
        //is_feasible = add_a_server(node_id);
        //is_feasible = run_server_level_mcf();
        //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl<<endl;
        if(is_feasible && global_min_cost < best_cost)
        {
            //zkw_mcf->set_state_from_cur_state();
            best_cost = global_min_cost;
        }
        else
        {
            memcpy(servers, pre_servers, sizeof(int) * node_num);
            global_min_cost = best_cost;
        }
        //if(node_id == 150) break;
        //break;
        //cout<<i<<" "<<servers[i]<<endl;
    }
    cout<<"cnts: "<<cnt<<endl;
    cout<<"min cost after increase_server_with_server_level: "<<global_min_cost<<endl;

    clock_t end = clock();
    printf("Use Time:%f\n",(double(end-start)/CLOCKS_PER_SEC));

    if(global_min_cost < begin_cost) return true;
    return false;
}

void OptSearch::set_mcf_state(int which)
{
    //run_server_level_mcf();
    if(which == 0)  run_max_level_mcf();
    else run_server_level_mcf();
    zkw_mcf->set_state_from_cur_state();
}

bool OptSearch::down_server_level()
{
    set_mcf_state(1);

    int node_id, best_cost = global_min_cost, begin_cost = global_min_cost;
    bool changed, is_feasible;
    while(true)
    {
        calculate_candidates_overflow_cost();
        sort(candidates.begin(), candidates.end(), candidate_overflow_cmp_greater());
        changed = false;
        for(int i = 0; i < node_num; i++)
        {
            node_id = candidates[i]->node_id;
            if(candidates[i]->overflow_cost <= 0.0 || servers[node_id] == -1) break;
            //cout<<node_id<<" "<<candidates[i]->overflow_cost<<endl;
            memcpy(pre_servers, servers, sizeof(int) * node_num);

            //servers[node_id]--;
            //is_feasible = run_server_level_mcf();
            //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl;

            //memcpy(servers, pre_servers, sizeof(int) * node_num);
            is_feasible = decrease_level_one_server(node_id, servers[node_id] - 1);
            //cout<<node_id<<" "<<is_feasible<<" "<<zkw_mcf->min_cost<<" "<<global_min_cost<<endl;

            if(is_feasible && global_min_cost < best_cost)
            {
                this->zkw_mcf->set_state_from_cur_state();
                best_cost = global_min_cost;
                changed = true;
                break;
            }
            else
            {
                memcpy(servers, pre_servers, sizeof(int) * node_num);
                global_min_cost = best_cost;
            }
        }
        if(!changed) break;
    }

    //cout<<"min cost after down_server_level: "<<global_min_cost<<endl;
    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::exchange_server_by_node_pass_cost_lv2()
{
    //cout<<111<<endl;
    calculate_candidates_pass_cost();
    sort(candidates.begin(), candidates.end(), candidate_pass_cost_cmp_greater());

    int begin_cost = global_min_cost;
    for(int i = 0; i < node_num; i++)
    {
        if(servers[i] == -1) continue;
        exchange_one_server_with_other_candidates(i);
    }

    cout<<"min cost after exchange_server_by_node_pass_cost: "<<global_min_cost<<endl;

    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::exchange_one_server_with_other_candidates(int out_id)
{
    int up;
    if(topo_lv == 0) up = 100;
    else if(topo_lv == 1) up = 150;
    else up = 20;

    int in_lv, ret, real_lv, in_id, cnt = 0;
    bool succeed = false;
    for(int i = 0; i < node_num; i++)
    {
        //if(increase_candidates_cp[i] == empty_candidate) continue;
        in_id = candidates[i]->node_id;
        if(servers[in_id] != -1) continue;
        if(topo_lv <= 2)
        {
            cnt++;
            if(cnt >= up) break;
        }

        ret = exchange_node(in_id, servers[out_id], out_id, real_lv);
        if(ret == 2 || ret == 1) continue;
        if(ret == 0)
        {
            succeed = true;
            break;
        }
        //ret = exchange_node(in_id, real_lv - 1, out_id, real_lv);
        //if(ret == 0) succeed = true;
        if(succeed) break;
    }

    return succeed;
}

bool OptSearch::exchange_server_by_node_pass_cost()
{
    calculate_candidates_pass_cost();
    sort(candidates.begin(), candidates.end(), candidate_pass_cost_cmp_greater());

    int begin_cost = global_min_cost;
    int in_id;
    for(int i = 0; i < node_num; i++)
    {
        in_id = candidates[i]->node_id;
        //if(increase_candidates_cp[in_id] == empty_candidate) continue;
        if(servers[in_id] != -1) continue;
        exchange_one_node_with_all_server(in_id);
    }

    cout<<"min cost after exchange_server_by_node_pass_cost: "<<global_min_cost<<endl;

    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::exchange_one_node_with_all_server(int in_id)
{
    int in_lv, ret, real_lv, out_id;
    bool succeed = false;
    for(int i = 0; i < node_num; i++)
    {
        if(servers[i] == -1) continue;
        out_id = i;
        ret = exchange_node(in_id, servers[out_id], out_id, real_lv);
        if(ret == 2 || ret == 1) continue;
        if(ret == 0)
        {
            succeed = true;
            break;
        }
        //ret = exchange_node(in_id, real_lv - 1, out_id, real_lv);
       // if(ret == 0) succeed = true;
        if(succeed) break;
    }

    return succeed;
}

int OptSearch::exchange_node(int in_id, int in_lv, int out_id, int& real_lv)
{
    if(servers[in_id] != -1 || servers[out_id] == -1)
    {
        cout<<"exchange_node error"<<endl;
        return 2;
    }

    int best_cost = global_min_cost;
    int tmp_lv = servers[out_id];

    memcpy(pre_servers, servers, sizeof(int) * node_num);


    servers[in_id] = in_lv;
    servers[out_id] = -1;
    bool is_feasible = run_server_level_mcf();

    if(is_feasible)
    {
        real_lv = servers[in_id];
        if(global_min_cost < best_cost)
        {
            zkw_mcf->set_state_from_cur_state();
            return 0;
        }
        else
        {
            memcpy(servers, pre_servers, sizeof(int) * node_num);
            global_min_cost = best_cost;
            return 1;
        }
    }
    else
    {
        servers[out_id] = tmp_lv;
        servers[in_id] = -1;
        global_min_cost = best_cost;
        return 2;
    }

}

bool OptSearch::exchange_server_with_neighbor()
{
    int best_cost = global_min_cost, begin_cost = global_min_cost;
    int in_id, out_id, ret, lv;
    for(int i = 0; i < node_num; i++)
    {
        if(servers[i] == -1) continue;
        out_id = i;
        for(int j = g_node_head[i]; j != -1; j = g_edge_next[j])
        {
            in_id = g_edge_des[j];
            if(servers[in_id] != -1) continue;
            ret = exchange_node(in_id, servers[out_id], out_id, lv);
            if(ret == 0) break;
        }
    }

    cout<<"min cost after exchange_server_with_neighbor: "<<global_min_cost<<endl;

    if(global_min_cost < begin_cost) return true;
    return false;
}

bool OptSearch::decrease_level_one_server(int server_id, int target_level)
{
  //cout << "LALALALA!" << endl;
  if (target_level < -1 || target_level >= servers[server_id])
  {
    cout << "Decrease level: Invalid target level! ";
    cout << "(must be: -1 <= target_level < cur_level)" << endl;
    return true;
  }
  int old_level = servers[server_id];
  servers[server_id] = target_level;
  bool is_feasible = zkw_mcf->decrease_server_level(servers, server_id, old_level);
  //bool is_feasible = run_server_level_mcf();
  if (is_feasible)
  {
    update_global_min_cost();
  }
  return is_feasible;
}

bool OptSearch::increase_level_one_server(int server_id, int target_level)
{
  if (servers[server_id] >= level_num)
  {
    cout << "The level of server on net node " << server_id << "is the maximum level." << endl;
    return true;
  }
  if (target_level <= servers[server_id] || target_level >= level_num)
  {
    cout << "Increase level: Invalid target level! ";
    cout << "(must be: cur_level < target_level < level_num)" << endl;
    return true;
  }

  servers[server_id] = target_level;
  bool is_feasible = zkw_mcf->increase_server_level(servers, server_id, target_level);
  //cout << "increase level one server: " << endl;
  //print_solution();
  //cout << "target level: " << target_level << endl;
  //cout << servers[server_id] << endl;
  if (is_feasible) update_global_min_cost();
  //cout << servers[server_id] << endl;
  //print_solution();
  return is_feasible;
}

#endif
