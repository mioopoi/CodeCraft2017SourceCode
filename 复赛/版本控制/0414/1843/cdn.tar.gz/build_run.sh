#!/bin/bash

#mycase="topo.txt"
#result="topo_result.txt"

mycase="case3.txt"
result="result3.txt"

rm cdn.tar.gz

./build.sh

cd ./bin


./cdn ../../case_example/2/$mycase ../../case_result/2/$result