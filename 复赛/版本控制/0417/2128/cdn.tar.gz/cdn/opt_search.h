#ifndef __OPT_SEARCH_H__
#define __OPT_SEARCH_H__

#include <iostream>
#include <vector>
#include <algorithm>

#include "opt_search_helper.h"
#include "graph.h"
#include "net_simplex_mcf.h"

#define MAX_LEVEL_FLOW_COST 0
#define SERVER_LEVEL_FLOW_COST 1
class OptSearch
{
public:
    Graph* graph;
    NetSimplexMCF* mcf_simplex;
    int node_num;
    int customer_num;
    int level_num;

    vector<Candidate*> candidates;
    vector<Candidate*> candidates_cp;
    Candidate* candidate_start_ptr;

    int global_min_cost;
    int* servers;
    int* pre_servers;
    Candidate* empty_candidate;
    int topo_lv;

public:
    OptSearch(Graph* graph);
    void init_candidates();
    bool show_detail_info();

public:
    void calculate_candidates_neighbor();
    int choose_server_by_node_demand(double percent);
    int choose_server_by_node_max_flow(bool re_cal, double percent);

    void construct_first_solution_combine_demand_and_flow();

public:
    bool run_simplex_mcf(int run_type);
public:
    void deal_with_topo_lv0_zero();
};

OptSearch::OptSearch(Graph* graph)
{
    this->graph = graph;
    mcf_simplex = new NetSimplexMCF(graph);
    node_num = graph->node_num;
    customer_num =graph->customer_num;
    level_num = graph->level_num;

    servers = new int[node_num];
    pre_servers = new int[node_num];

    memset(servers, -1, sizeof(int) * node_num);

    global_min_cost = INF;
    init_candidates();

    if(node_num < 200) topo_lv = 0;
    else if(node_num < 500) topo_lv = 1;
    else topo_lv = 2;
}

void OptSearch::init_candidates()
{
    int candidate_ptr_cnt = 0;
    candidate_start_ptr = new Candidate[node_num + 2];

    empty_candidate = new (candidate_start_ptr + candidate_ptr_cnt) Candidate();
    candidate_ptr_cnt++;

    candidates = vector<Candidate*>(node_num, NULL);
    candidates_cp = vector<Candidate*>(node_num, NULL);

    bool is_customer;
    int demand;
    for(int i = 0; i < node_num; i++)
    {
        if(g_node_customer[i] != -1)
        {
            is_customer = true;
            demand = g_customer_need[g_node_customer[i]];
        }
        else
        {
            is_customer = false;
            demand = 0;
        }
        candidates[i] = new (candidate_start_ptr + candidate_ptr_cnt) Candidate(i, demand, g_node_cost[i]);
        candidates_cp[i] = candidates[i];
        candidate_ptr_cnt++;
    }
}

void OptSearch::calculate_candidates_neighbor()
{
    int max_flow, cus_num, des;
    for(int i = 0; i < node_num; i++)
    {
        max_flow = 0, cus_num = 0;
        if(g_node_customer[i] != -1)
            cus_num++;
        for(int j = g_node_head[i]; j != -1; j = g_edge_next[j])
        {
            max_flow += g_edge_cap[j];
            des = g_edge_des[j];
            if(g_node_customer[des] != -1)
                cus_num++;
        }
        candidates_cp[i]->max_flow = max_flow;
        candidates_cp[i]->cus_num = cus_num;
        //cout<<i<<" "<<max_flow<<" "<<cus_num<<endl;
    }
}

int OptSearch::choose_server_by_node_demand(double percent)
{
    sort(candidates.begin(), candidates.end(), candidate_demand_cmp_greater());

    int cus_num = int(customer_num * percent);
    int cus_cnt = 0, node_id;
    for(int i = 0; i < cus_num; i++)
    {
        node_id = candidates[i]->node_id;
        servers[node_id] = level_num - 1;
    }

    //sort(increase_candidates.begin(), increase_candidates.end(), candidate_demand_cmp_greater());
    //for(int i = 0; i < node_num; i++)
    //cout<<increase_candidates[i]->node_id<<endl;
    return cus_num;
}

int OptSearch::choose_server_by_node_max_flow(bool re_cal, double percent)
{
    if(re_cal)  calculate_candidates_neighbor();
    sort(candidates.begin(), candidates.end(), candidate_flow_cmp_greater());

    int middle_num = int(node_num * percent);
    int node_id;
    for(int i = 0; i < middle_num; i++)
    {
        node_id = candidates[i]->node_id;
        servers[node_id] = level_num - 1;
    }
    return middle_num;
}

void OptSearch::construct_first_solution_combine_demand_and_flow()
{
    double p0 = 0.1, p1 = 0.1;
    choose_server_by_node_demand(p0);
    choose_server_by_node_max_flow(true, p1);
    bool is_feasible = run_simplex_mcf(MAX_LEVEL_FLOW_COST);
    cout<<is_feasible<<" "<<global_min_cost<<endl;
    while(!is_feasible)
    {
        p0 += 0.1;
        p1 += 0.1;
        cout<<p0<<" "<<p1<<endl;
        choose_server_by_node_demand(p0);
        choose_server_by_node_max_flow(false, p1);
        is_feasible = run_simplex_mcf(MAX_LEVEL_FLOW_COST);
    }
}

//update_type 0 最大等级跑，按流量更新服务器
//run_type  1    服务器等级跑，按更新更新服务器

bool OptSearch::run_simplex_mcf(int run_type)
{
    bool is_feasible;
    if(run_type == MAX_LEVEL_FLOW_COST)
    {
        mcf_simplex->init(this->servers, 1);
        is_feasible = mcf_simplex->solve();
        if(is_feasible)
        {
            memset(servers, -1, sizeof(int) * node_num);
            global_min_cost = mcf_simplex->calculate_total_cost(servers, 0);
        }
    }
    if(run_type == SERVER_LEVEL_FLOW_COST)
    {
        mcf_simplex->init(this->servers, 0);
        is_feasible = mcf_simplex->solve();
        if(is_feasible)
        {
            memset(servers, -1, sizeof(int) * node_num);
            global_min_cost = mcf_simplex->calculate_total_cost(servers, 0);
        }
    }

    return is_feasible;
}

void OptSearch::deal_with_topo_lv0_zero()
{
    construct_first_solution_combine_demand_and_flow();

    //show_detail_info();

    run_simplex_mcf(1);
    //show_detail_info();
}

bool OptSearch::show_detail_info()
{

    for(int i = 0; i < node_num; i++)
    {
        if(servers[i] != -1)
        {
            cout<<i<<" "<<servers[i]<<endl;
        }
    }
    cout<<endl<<"min cost: "<<global_min_cost<<endl;

}


#endif // __OPT_SEARCH_H__
