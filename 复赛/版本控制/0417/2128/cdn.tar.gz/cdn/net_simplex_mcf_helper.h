#ifndef __MCF_SIMPLEX_HELPER_H__
#define __MCF_SIMPLEX_HELPER_H__

const char BASIC_EDGE = 0;
const char EDGE_LOWER = 1;
const char EDGE_UPPER = 2;

const int N_CANDIDATE_LIST_L = 30;
const int N_CANDIDATE_LIST_M = 50;
const int N_CANDIDATE_LIST_H = 200;
const int SIZE_HOT_LIST_L = 5;
const int SIZE_HOT_LIST_M = 10;
const int SIZE_HOT_LIST_H = 20;

const int UNSOLVED = -1;
const int OPTIMAL_SOLVED = 0;
const int UNFEASIBLE = 1;
const int UNBOUNDED = 2;

struct Edge;

struct Node
{
	int balance;
	int potential;
	int sub_tree_lv;

	struct Edge *entering_edge;

	struct Node *prev;
	struct Node *next;
};

struct Edge
{
	int cap, flow, cost;
	char ident;

	struct Node *first;
	struct Node *last;
};

struct Candidate_T
{
	struct Edge *edge;
	int abs_rc;
};

#endif